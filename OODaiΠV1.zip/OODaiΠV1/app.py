import json
import os
import uuid
import re
import urllib.parse
import tornado.ioloop
import tornado.web
import tornado.websocket
import tornado.httpclient
from tornado.escape import json_decode, json_encode

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, 'config', 'config.json')

# Load config once at startup
if not os.path.exists(CONFIG_PATH):
    os.makedirs(os.path.join(BASE_DIR, 'config'), exist_ok=True)
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump({
            "servers": ["ws://localhost:8888/ws"],
            "room": "default",
            "ai": {
                "base_url": "https://api.siliconflow.cn/v1/",
                "model": "Qwen/Qwen3-8B"
            }
        }, f, ensure_ascii=False, indent=2)

with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
    APP_CONFIG = json.load(f)

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.redirect('/login')

class LoginHandler(tornado.web.RequestHandler):
    def get(self):
        self.render('login.html')

class ChatHandler(tornado.web.RequestHandler):
    def get(self):
        nick = self.get_argument('nick', '')
        server = self.get_argument('server', '')
        if not nick:
            self.redirect('/login')
            return
        self.render('chat.html', nick=nick, server=server)

class ConfigHandler(tornado.web.RequestHandler):
    def get(self):
        self.set_header('Content-Type', 'application/json; charset=utf-8')
        self.write(json.dumps(APP_CONFIG, ensure_ascii=False))

class ApiLoginHandler(tornado.web.RequestHandler):
    def post(self):
        try:
            data = json_decode(self.request.body or '{}')
        except Exception:
            data = {
                'nickname': self.get_argument('nickname', ''),
                'password': self.get_argument('password', '')
            }
        nickname = (data.get('nickname') or '').strip()
        password = (data.get('password') or '').strip()
        if not nickname:
            self.write({'ok': False, 'msg': '昵称不能为空'})
            return
        if password != '123456':
            self.write({'ok': False, 'msg': '密码错误，固定密码为 123456'})
            return
        self.write({'ok': True})

class ChatWebSocket(tornado.websocket.WebSocketHandler):
    # Allow cross-origin for dev usage
    def check_origin(self, origin):
        return True

    clients = set()

    def open(self):
        self.nick = self.get_argument('nick', '匿名')
        self.room = APP_CONFIG.get('room', 'default')
        ChatWebSocket.clients.add(self)
        system_msg = {
            'type': 'system',
            'nick': '系统',
            'text': f"{self.nick} 加入了聊天室",
        }
        self.broadcast(system_msg)

    def on_message(self, message):
        try:
            data = json_decode(message)
        except Exception:
            data = {'type': 'chat', 'nick': self.nick, 'text': message}
        msg_type = data.get('type', 'chat')
        nick = data.get('nick') or self.nick
        text = data.get('text', '')

        # Handle @ commands
        commands = ['@成小理', '@音乐一下', '@电影', '@天气', '@新闻', '@小视频']
        matched = None
        for c in commands:
            if text.strip().startswith(c):
                matched = c
                break
        if matched == '@成小理':
            # Echo user's command into chat so it appears immediately
            self.broadcast({'type': 'chat', 'nick': nick, 'text': text})
            # Stream response from SiliconFlow OpenAI-compatible API via SSE
            msg_id = str(uuid.uuid4())
            start = {
                'type': 'bot_stream_start',
                'nick': '成小理',
                'msg_id': msg_id,
                'text': ''
            }
            self.broadcast(start)
            prompt = text[len('@成小理'):].strip() or '你好'
            tornado.ioloop.IOLoop.current().spawn_callback(self.handle_ai_stream, prompt, msg_id)
            return
        elif matched == '@电影':
            # Echo user's command
            self.broadcast({'type': 'chat', 'nick': nick, 'text': text})
            # Parse URL inside command, format: @电影[url]
            m = re.search(r"@电影\s*\[(.*?)\]", text)
            if not m:
                self.broadcast({'type': 'bot', 'nick': 'OODaiP助理', 'text': '用法：@电影[URL]，例如 @电影[https://example.com/player]'});
                return
            url = (m.group(1) or '').strip()
            if not url:
                self.broadcast({'type': 'bot', 'nick': 'OODaiP助理', 'text': '未检测到 URL，请按 @电影[URL] 的格式发送'});
                return
            # Build parsing server url
            parser_prefix = 'https://jx.m3u8.tv/jiexi/?url='
            embed_url = parser_prefix + urllib.parse.quote(url, safe='')
            # Broadcast iframe embed info to front-end (fixed 400x400)
            self.broadcast({
                'type': 'movie',
                'nick': 'OODaiP点映台',
                'text': '正在播放嵌入内容',
                'url': embed_url,
                'width': 400,
                'height': 400
            })
            return
        elif matched:
            bot = {
                'type': 'bot',
                'nick': 'OODaiP助理',
                'text': f"{matched} 功能正在建设中，当前仅做占位与回显（数据已接收并响应）。",
            }
            self.broadcast(bot)
        else:
            self.broadcast({'type': msg_type, 'nick': nick, 'text': text})

    async def handle_ai_stream(self, prompt: str, msg_id: str):
        api_key = (os.environ.get('OODAI_SF_API_KEY', '') or (APP_CONFIG.get('ai', {}) or {}).get('api_key', '')).strip()
        base_url = (APP_CONFIG.get('ai', {}) or {}).get('base_url', 'https://api.siliconflow.cn/v1/')
        model_name = (APP_CONFIG.get('ai', {}) or {}).get('model', 'Qwen/Qwen3-8B')
        endpoint = base_url.rstrip('/') + '/chat/completions'

        if not api_key:
            self.broadcast({'type': 'bot_stream_error', 'nick': '成小理', 'msg_id': msg_id, 'text': '未配置 API 密钥，请设置环境变量 OODAI_SF_API_KEY 或在 config.json 的 ai.api_key 中配置后重试。'})
            self.broadcast({'type': 'bot_stream_end', 'nick': '成小理', 'msg_id': msg_id})
            return

        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        body = json.dumps({
            'model': model_name,
            'messages': [
                {'role': 'system', 'content': 'You are a helpful assistant named 成小理.'},
                {'role': 'user', 'content': prompt}
            ],
            'stream': True
        }, ensure_ascii=False)

        client = tornado.httpclient.AsyncHTTPClient()

        def on_chunk(chunk: bytes):
            try:
                text = chunk.decode('utf-8', errors='ignore')
            except Exception:
                text = ''
            for line in text.split('\n'):
                line = line.strip()
                if not line:
                    continue
                if line.startswith('data:'):
                    payload = line[5:].strip()
                    if payload == '[DONE]':
                        self.broadcast({'type': 'bot_stream_end', 'nick': '成小理', 'msg_id': msg_id})
                        continue
                    try:
                        j = json.loads(payload)
                    except Exception:
                        continue
                    # OpenAI ChatCompletion stream format
                    chs = j.get('choices') or []
                    if chs:
                        delta = (chs[0].get('delta') or {}).get('content')
                        if delta:
                            self.broadcast({'type': 'bot_stream_delta', 'nick': '成小理', 'msg_id': msg_id, 'text': delta})

        try:
            req = tornado.httpclient.HTTPRequest(
                endpoint,
                method='POST',
                headers=headers,
                body=body,
                request_timeout=120,
                streaming_callback=on_chunk,
            )
            await client.fetch(req)
        except Exception as e:
            self.broadcast({'type': 'bot_stream_error', 'nick': '成小理', 'msg_id': msg_id, 'text': 'AI服务请求失败，请稍后重试。'})
            self.broadcast({'type': 'bot_stream_end', 'nick': '成小理', 'msg_id': msg_id})

    def on_close(self):
        if self in ChatWebSocket.clients:
            ChatWebSocket.clients.remove(self)
        system_msg = {
            'type': 'system',
            'nick': '系统',
            'text': f"{getattr(self, 'nick', '匿名')} 离开了聊天室",
        }
        self.broadcast(system_msg)

    @classmethod
    def broadcast(cls, data):
        payload = json_encode(data)
        dead = []
        for c in list(cls.clients):
            try:
                c.write_message(payload)
            except Exception:
                dead.append(c)
        for d in dead:
            try:
                cls.clients.remove(d)
            except Exception:
                pass

def make_app():
    settings = {
        'debug': True,
        'template_path': os.path.join(BASE_DIR, 'templates'),
        'static_path': os.path.join(BASE_DIR, 'static'),
    }
    return tornado.web.Application([
        (r"/", MainHandler),
        (r"/login", LoginHandler),
        (r"/chat", ChatHandler),
        (r"/config", ConfigHandler),
        (r"/api/login", ApiLoginHandler),
        (r"/ws", ChatWebSocket),
        (r"/static/(.*)", tornado.web.StaticFileHandler, {'path': settings['static_path']}),
    ], **settings)

if __name__ == "__main__":
    app = make_app()
    port = int(APP_CONFIG.get('port', 8888))
    app.listen(port, address="127.0.0.1")
    print(f"OODaiP聊天室 已启动: http://127.0.0.1:{port}/")
    tornado.ioloop.IOLoop.current().start()