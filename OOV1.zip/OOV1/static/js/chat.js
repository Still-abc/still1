/**
 * OO聊天室 - 聊天室脚本
 */

// 全局变量
let ws = null;
let currentUser = null;
let serverUrl = null;
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;

// 常用Emoji列表
const emojis = [
    '😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂',
    '🙂', '😊', '😇', '🥰', '😍', '🤩', '😘', '😗',
    '😚', '😙', '🥲', '😋', '😛', '😜', '🤪', '😝',
    '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐',
    '😑', '😶', '😏', '😒', '🙄', '😬', '🤥', '😌',
    '😔', '😪', '🤤', '😴', '😷', '🤒', '🤕', '🤢',
    '🤮', '🤧', '🥵', '🥶', '🥴', '😵', '🤯', '🤠',
    '🥳', '🥸', '😎', '🤓', '🧐', '😕', '😟', '🙁',
    '☹️', '😮', '😯', '😲', '😳', '🥺', '😦', '😧',
    '😨', '😰', '😥', '😢', '😭', '😱', '😖', '😣',
    '😞', '😓', '😩', '😫', '🥱', '😤', '😡', '😠',
    '🤬', '😈', '👿', '💀', '☠️', '💩', '🤡', '👹',
    '👺', '👻', '👽', '👾', '🤖', '😺', '😸', '😹',
    '😻', '😼', '😽', '🙀', '😿', '😾', '🙈', '🙉',
    '🙊', '💋', '💌', '💘', '💝', '💖', '💗', '💓',
    '💞', '💕', '💟', '❣️', '💔', '❤️', '🧡', '💛',
    '💚', '💙', '💜', '🤎', '🖤', '🤍', '💯', '💢',
    '💥', '💫', '💦', '💨', '🕳️', '💣', '💬', '👁️‍🗨️',
    '🗨️', '🗯️', '💭', '💤', '👋', '🤚', '🖐️', '✋',
    '🖖', '👌', '🤌', '🤏', '✌️', '🤞', '🤟', '🤘',
    '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️', '👍',
    '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '👐',
    '🤲', '🤝', '🙏', '✍️', '💅', '🤳', '💪', '🦾'
];

$(document).ready(function() {
    // 检查登录状态
    checkLoginStatus();
    
    // 初始化Emoji选择器
    initEmojiPicker();
    
    // 绑定事件
    bindEvents();
});

/**
 * 检查登录状态
 */
function checkLoginStatus() {
    currentUser = sessionStorage.getItem('oo_nickname');
    serverUrl = sessionStorage.getItem('oo_server');
    
    if (!currentUser || !serverUrl) {
        // 未登录，跳转到登录页
        window.location.href = '/';
        return;
    }
    
    // 显示当前用户信息
    $('#currentUsername').text(currentUser);
    $('#currentUserInitial').text(currentUser.charAt(0).toUpperCase());
    
    // 连接WebSocket
    connectWebSocket();
}

/**
 * 连接WebSocket
 */
function connectWebSocket() {
    showConnectionStatus('connecting', '连接中...');
    
    // 使用用户选择的服务器地址
    const wsUrl = serverUrl;
    console.log('Connecting to:', wsUrl);
    
    try {
        ws = new WebSocket(wsUrl);
        
        ws.onopen = function() {
            console.log('WebSocket connected');
            reconnectAttempts = 0;
            showConnectionStatus('connected', '已连接');
            
            // 发送加入消息
            ws.send(JSON.stringify({
                type: 'join',
                nickname: currentUser
            }));
            
            // 3秒后隐藏连接状态
            setTimeout(hideConnectionStatus, 3000);
        };
        
        ws.onmessage = function(event) {
            const message = JSON.parse(event.data);
            handleMessage(message);
        };
        
        ws.onclose = function() {
            console.log('WebSocket disconnected');
            showConnectionStatus('disconnected', '连接断开');
            
            // 尝试重连
            if (reconnectAttempts < maxReconnectAttempts) {
                reconnectAttempts++;
                setTimeout(connectWebSocket, 3000);
            }
        };
        
        ws.onerror = function(error) {
            console.error('WebSocket error:', error);
            showConnectionStatus('disconnected', '连接错误');
        };
        
    } catch (error) {
        console.error('WebSocket connection failed:', error);
        showConnectionStatus('disconnected', '连接失败');
    }
}

/**
 * 处理收到的消息
 */
function handleMessage(message) {
    switch (message.type) {
        case 'message':
            appendChatMessage(message);
            break;
        case 'system':
            // 移除所有加载提示
            removeMusicLoading();
            removeWeatherLoading();
            removeHoroscopeLoading();
            removeNewsLoading();
            removeAiThinking();
            appendSystemMessage(message.content, message.timestamp);
            break;
        case 'user_list':
            updateUserList(message.users);
            break;
        case 'movie':
            appendMovieMessage(message);
            break;
        case 'ai_thinking':
            appendAiThinking();
            break;
        case 'ai_reply':
            removeAiThinking();
            appendAiReply(message);
            break;
        case 'music_loading':
            appendMusicLoading();
            break;
        case 'music':
            removeMusicLoading();
            appendMusicCard(message);
            break;
        case 'weather_loading':
            appendWeatherLoading(message.city);
            break;
        case 'weather':
            removeWeatherLoading();
            appendWeatherCard(message);
            break;
        case 'horoscope_loading':
            appendHoroscopeLoading(message.sign);
            break;
        case 'horoscope':
            removeHoroscopeLoading();
            appendHoroscopeCard(message);
            break;
        case 'news_loading':
            appendNewsLoading();
            break;
        case 'news':
            removeNewsLoading();
            appendNewsCard(message);
            break;
    }
}

/**
 * 显示新闻加载中
 */
function appendNewsLoading() {
    $('.welcome-message').remove();
    $('.news-loading').remove();
    
    const loadingHtml = `
        <div class="message news-loading">
            <div class="msg-avatar news-avatar">📰</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname news-name">新闻助手</span>
                </div>
                <div class="msg-bubble news-loading-bubble">
                    <span class="news-loading-icon">📡</span>
                    <span class="news-loading-text">正在获取最新资讯...</span>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(loadingHtml);
    scrollToBottom();
}

/**
 * 移除新闻加载提示
 */
function removeNewsLoading() {
    $('.news-loading').remove();
}

/**
 * 添加新闻卡片
 */
function appendNewsCard(message) {
    $('.welcome-message').remove();
    
    const newsList = message.news_list || [];
    
    // 生成新闻列表HTML
    let newsItemsHtml = '';
    newsList.forEach((news, index) => {
        const title = news.title || news.name || '无标题';
        const url = news.url || news.link || '#';
        const source = news.source || news.author || '';
        const hot = news.hot || news.hotValue || '';
        
        newsItemsHtml += `
            <a href="${escapeHtml(url)}" target="_blank" class="news-item">
                <span class="news-index">${index + 1}</span>
                <span class="news-title">${escapeHtml(title)}</span>
                ${hot ? `<span class="news-hot">🔥${escapeHtml(hot)}</span>` : ''}
            </a>
        `;
    });
    
    const messageHtml = `
        <div class="message">
            <div class="msg-avatar news-avatar">📰</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname news-name">新闻助手</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="news-card">
                    <div class="news-header">
                        <span class="news-card-title">📰 今日热点</span>
                    </div>
                    <div class="news-list">
                        ${newsItemsHtml || '<div class="news-empty">暂无新闻</div>'}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 显示星座加载中
 */
function appendHoroscopeLoading(sign) {
    $('.welcome-message').remove();
    $('.horoscope-loading').remove();
    
    const loadingHtml = `
        <div class="message horoscope-loading">
            <div class="msg-avatar horoscope-avatar">⭐</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname horoscope-name">星座大师</span>
                </div>
                <div class="msg-bubble horoscope-loading-bubble">
                    <span class="horoscope-loading-icon">🔮</span>
                    <span class="horoscope-loading-text">正在解读 ${escapeHtml(sign)} 的运势...</span>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(loadingHtml);
    scrollToBottom();
}

/**
 * 移除星座加载提示
 */
function removeHoroscopeLoading() {
    $('.horoscope-loading').remove();
}

/**
 * 转换星级评分为星星
 */
function parseStars(rating) {
    // 提取数字
    const match = rating.toString().match(/(\d)/);
    const num = match ? parseInt(match[1]) : 3;
    return '★'.repeat(num) + '☆'.repeat(5 - num);
}

/**
 * 添加星座运势卡片
 */
function appendHoroscopeCard(message) {
    $('.welcome-message').remove();
    
    const data = message.data;
    
    const messageHtml = `
        <div class="message">
            <div class="msg-avatar horoscope-avatar">⭐</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname">${escapeHtml(message.nickname)}</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="horoscope-card">
                    <div class="horoscope-header">
                        <div class="horoscope-sign">⭐ ${escapeHtml(data.sign)}</div>
                        <div class="horoscope-date">${escapeHtml(data.date)}</div>
                    </div>
                    <div class="horoscope-summary">${escapeHtml(data.summary || '')}</div>
                    <div class="horoscope-ratings">
                        <div class="rating-item">
                            <span class="rating-label">综合</span>
                            <span class="rating-stars">${parseStars(data.overall)}</span>
                        </div>
                        <div class="rating-item">
                            <span class="rating-label">爱情</span>
                            <span class="rating-stars love">${parseStars(data.love)}</span>
                        </div>
                        <div class="rating-item">
                            <span class="rating-label">事业</span>
                            <span class="rating-stars career">${parseStars(data.career)}</span>
                        </div>
                        <div class="rating-item">
                            <span class="rating-label">财运</span>
                            <span class="rating-stars wealth">${parseStars(data.wealth)}</span>
                        </div>
                        <div class="rating-item">
                            <span class="rating-label">健康</span>
                            <span class="rating-stars health">${parseStars(data.health)}</span>
                        </div>
                    </div>
                    <div class="horoscope-lucky">
                        <div class="lucky-item">
                            <span class="lucky-icon">🎨</span>
                            <span>幸运色: ${escapeHtml(data.lucky_color || 'N/A')}</span>
                        </div>
                        <div class="lucky-item">
                            <span class="lucky-icon">🔢</span>
                            <span>幸运数: ${escapeHtml(data.lucky_number || 'N/A')}</span>
                        </div>
                    </div>
                    <div class="horoscope-advice">💡 ${escapeHtml(data.advice || '')}</div>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 显示天气加载中
 */
function appendWeatherLoading(city) {
    $('.welcome-message').remove();
    $('.weather-loading').remove();
    
    const loadingHtml = `
        <div class="message weather-loading">
            <div class="msg-avatar weather-avatar">🌤️</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname weather-name">天气助手</span>
                </div>
                <div class="msg-bubble weather-loading-bubble">
                    <span class="weather-loading-icon">🔍</span>
                    <span class="weather-loading-text">正在查询 ${escapeHtml(city)} 的天气...</span>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(loadingHtml);
    scrollToBottom();
}

/**
 * 移除天气加载提示
 */
function removeWeatherLoading() {
    $('.weather-loading').remove();
}

/**
 * 添加天气卡片
 */
function appendWeatherCard(message) {
    $('.welcome-message').remove();
    
    const data = message.data;
    
    // 生成未来天气预报HTML
    let forecastHtml = '';
    if (data.forecast && data.forecast.length > 0) {
        forecastHtml = '<div class="weather-forecast">';
        data.forecast.forEach((day, index) => {
            const dayLabel = index === 0 ? '今天' : (index === 1 ? '明天' : '后天');
            forecastHtml += `
                <div class="forecast-day">
                    <div class="forecast-label">${dayLabel}</div>
                    <div class="forecast-temp">${day.min_temp}°~${day.max_temp}°</div>
                </div>
            `;
        });
        forecastHtml += '</div>';
    }
    
    const messageHtml = `
        <div class="message">
            <div class="msg-avatar weather-avatar">🌤️</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname">${escapeHtml(message.nickname)}</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="weather-card">
                    <div class="weather-header">
                        <div class="weather-city">📍 ${escapeHtml(data.city)}</div>
                    </div>
                    <div class="weather-main">
                        <div class="weather-temp-big">${data.temp}°C</div>
                        <div class="weather-desc">${data.weather}</div>
                    </div>
                    <div class="weather-details">
                        <div class="weather-detail-item">
                            <span class="detail-icon">🌡️</span>
                            <span class="detail-label">体感</span>
                            <span class="detail-value">${data.feels_like}°C</span>
                        </div>
                        <div class="weather-detail-item">
                            <span class="detail-icon">💧</span>
                            <span class="detail-label">湿度</span>
                            <span class="detail-value">${data.humidity}%</span>
                        </div>
                        <div class="weather-detail-item">
                            <span class="detail-icon">💨</span>
                            <span class="detail-label">风速</span>
                            <span class="detail-value">${data.wind_speed}km/h</span>
                        </div>
                        <div class="weather-detail-item">
                            <span class="detail-icon">👁️</span>
                            <span class="detail-label">能见度</span>
                            <span class="detail-value">${data.visibility}km</span>
                        </div>
                    </div>
                    ${forecastHtml}
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 显示音乐加载中
 */
function appendMusicLoading() {
    // 移除欢迎消息
    $('.welcome-message').remove();
    // 移除之前的加载提示
    $('.music-loading').remove();
    
    const loadingHtml = `
        <div class="message music-loading">
            <div class="msg-avatar music-avatar">🎵</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname music-name">音乐精灵</span>
                </div>
                <div class="msg-bubble music-loading-bubble">
                    <span class="music-loading-icon">🎶</span>
                    <span class="music-loading-text">正在为你挑选音乐...</span>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(loadingHtml);
    scrollToBottom();
}

/**
 * 移除音乐加载提示
 */
function removeMusicLoading() {
    $('.music-loading').remove();
}

/**
 * 添加音乐卡片
 */
function appendMusicCard(message) {
    // 移除欢迎消息
    $('.welcome-message').remove();
    
    // 生成唯一的播放器ID
    const playerId = 'player_' + Date.now();
    
    const messageHtml = `
        <div class="message">
            <div class="msg-avatar music-avatar">🎵</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname">${escapeHtml(message.nickname)}</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="music-card">
                    <div class="music-card-header">
                        <img class="music-cover" src="${escapeHtml(message.image)}" alt="封面" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect fill=%22%23667eea%22 width=%22100%22 height=%22100%22/><text x=%2250%22 y=%2255%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2240%22>🎵</text></svg>'">
                        <div class="music-info">
                            <div class="music-title">${escapeHtml(message.name)}</div>
                            <div class="music-singer">${escapeHtml(message.singer)}</div>
                        </div>
                    </div>
                    <div class="music-player-wrapper">
                        <audio id="${playerId}" class="music-audio" preload="metadata">
                            <source src="${escapeHtml(message.url)}" type="audio/mpeg">
                        </audio>
                        <div class="music-controls">
                            <button class="music-play-btn" data-player="${playerId}">
                                <span class="play-icon">▶</span>
                            </button>
                            <div class="music-progress-wrapper">
                                <div class="music-progress" data-player="${playerId}">
                                    <div class="music-progress-bar"></div>
                                </div>
                                <div class="music-time">
                                    <span class="current-time">0:00</span>
                                    <span class="total-time">0:00</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
    
    // 初始化播放器事件
    initMusicPlayer(playerId);
}

/**
 * 初始化音乐播放器
 */
function initMusicPlayer(playerId) {
    const audio = document.getElementById(playerId);
    const playBtn = $(`.music-play-btn[data-player="${playerId}"]`);
    const progress = $(`.music-progress[data-player="${playerId}"]`);
    const progressBar = progress.find('.music-progress-bar');
    const currentTimeEl = progress.siblings('.music-time').find('.current-time');
    const totalTimeEl = progress.siblings('.music-time').find('.total-time');
    const musicCard = playBtn.closest('.music-card');
    
    // 播放/暂停
    playBtn.on('click', function() {
        // 暂停其他正在播放的音乐
        $('audio.music-audio').each(function() {
            if (this.id !== playerId && !this.paused) {
                this.pause();
                $(`.music-play-btn[data-player="${this.id}"] .play-icon`).text('▶');
            }
        });
        
        if (audio.paused) {
            audio.play().then(function() {
                playBtn.find('.play-icon').text('⏸');
            }).catch(function(error) {
                console.error('播放失败:', error);
                alert('音乐加载失败，可能是音源已过期，请重新获取');
            });
        } else {
            audio.pause();
            $(this).find('.play-icon').text('▶');
        }
    });
    
    // 更新进度
    audio.addEventListener('timeupdate', function() {
        const percent = (audio.currentTime / audio.duration) * 100;
        progressBar.css('width', percent + '%');
        currentTimeEl.text(formatTime(audio.currentTime));
    });
    
    // 加载元数据
    audio.addEventListener('loadedmetadata', function() {
        totalTimeEl.text(formatTime(audio.duration));
    });
    
    // 可以播放时
    audio.addEventListener('canplay', function() {
        console.log('音乐可以播放:', playerId);
    });
    
    // 加载错误
    audio.addEventListener('error', function(e) {
        console.error('音乐加载错误:', e);
        totalTimeEl.text('加载失败');
        musicCard.find('.music-title').after('<div class="music-error">音源加载失败</div>');
    });
    
    // 播放结束
    audio.addEventListener('ended', function() {
        playBtn.find('.play-icon').text('▶');
        progressBar.css('width', '0%');
    });
    
    // 点击进度条跳转
    progress.on('click', function(e) {
        const rect = this.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        audio.currentTime = percent * audio.duration;
    });
}

/**
 * 格式化时间
 */
function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return mins + ':' + (secs < 10 ? '0' : '') + secs;
}

/**
 * 显示AI正在思考
 */
function appendAiThinking() {
    // 移除欢迎消息
    $('.welcome-message').remove();
    // 移除之前的思考提示
    $('.ai-thinking').remove();
    
    const thinkingHtml = `
        <div class="message ai-thinking">
            <div class="msg-avatar ai-avatar">🤖</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname ai-name">成小理</span>
                </div>
                <div class="msg-bubble ai-bubble thinking-bubble">
                    <span class="thinking-dots">
                        <span>●</span><span>●</span><span>●</span>
                    </span>
                    <span class="thinking-text">正在思考中...</span>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(thinkingHtml);
    scrollToBottom();
}

/**
 * 移除AI思考提示
 */
function removeAiThinking() {
    $('.ai-thinking').remove();
}

/**
 * 添加AI回复消息
 */
function appendAiReply(message) {
    // 移除欢迎消息
    $('.welcome-message').remove();
    
    const messageHtml = `
        <div class="message ai-message">
            <div class="msg-avatar ai-avatar">🤖</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname ai-name">成小理</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="msg-bubble ai-bubble">${formatAiContent(message.content)}</div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 格式化AI回复内容（支持简单的markdown）
 */
function formatAiContent(content) {
    let formatted = escapeHtml(content);
    // 处理换行
    formatted = formatted.replace(/\n/g, '<br>');
    // 处理代码块
    formatted = formatted.replace(/`([^`]+)`/g, '<code>$1</code>');
    return formatted;
}

/**
 * 添加电影播放消息
 */
function appendMovieMessage(message) {
    // 移除欢迎消息
    $('.welcome-message').remove();
    
    const parseServer = 'https://jx.m3u8.tv/jiexi/?url=';
    const iframeSrc = parseServer + encodeURIComponent(message.video_url);
    
    const messageHtml = `
        <div class="message">
            <div class="msg-avatar" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%); font-size: 20px;">🎬</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname">${escapeHtml(message.nickname)}</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="msg-bubble movie-bubble">
                    <div class="movie-title">🎬 分享了一部电影</div>
                    <div class="movie-player">
                        <iframe 
                            src="${iframeSrc}" 
                            width="400" 
                            height="400" 
                            frameborder="0" 
                            allowfullscreen="true"
                            allow="autoplay; encrypted-media"
                            scrolling="no"
                        ></iframe>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 添加聊天消息
 */
function appendChatMessage(message) {
    // 移除欢迎消息
    $('.welcome-message').remove();
    
    const isSelf = message.nickname === currentUser;
    const initial = message.nickname.charAt(0).toUpperCase();
    
    const messageHtml = `
        <div class="message ${isSelf ? 'self' : ''}">
            <div class="msg-avatar">${initial}</div>
            <div class="msg-content">
                <div class="msg-header">
                    <span class="msg-nickname">${escapeHtml(message.nickname)}</span>
                    <span class="msg-time">${message.timestamp}</span>
                </div>
                <div class="msg-bubble">${formatMessageContent(message.content)}</div>
            </div>
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 添加系统消息
 */
function appendSystemMessage(content, timestamp) {
    // 移除欢迎消息
    $('.welcome-message').remove();
    
    const messageHtml = `
        <div class="system-message">
            ${escapeHtml(content)} · ${timestamp}
        </div>
    `;
    
    $('#messagesWrapper').append(messageHtml);
    scrollToBottom();
}

/**
 * 格式化消息内容（处理@提及等）
 */
function formatMessageContent(content) {
    let formatted = escapeHtml(content);
    
    // 高亮@提及
    const atPattern = /@(成小理|音乐|电影|天气|新闻|小视频)/g;
    formatted = formatted.replace(atPattern, '<span style="color: #667eea; font-weight: 600;">@$1</span>');
    
    // 高亮@用户
    const userPattern = /@(\S+)/g;
    formatted = formatted.replace(userPattern, function(match, username) {
        if (['成小理', '音乐', '电影', '天气', '新闻', '小视频'].includes(username)) {
            return match; // 已经处理过的功能@
        }
        return `<span style="color: #764ba2; font-weight: 500;">${match}</span>`;
    });
    
    return formatted;
}

/**
 * 更新用户列表
 */
function updateUserList(users) {
    const $userList = $('#userList');
    $userList.empty();
    
    users.forEach(function(user) {
        const initial = user.charAt(0).toUpperCase();
        const isCurrentUser = user === currentUser;
        
        $userList.append(`
            <li class="${isCurrentUser ? 'current' : ''}" data-user="${escapeHtml(user)}">
                <div class="user-avatar">${initial}</div>
                <span class="user-name">${escapeHtml(user)}${isCurrentUser ? ' (我)' : ''}</span>
            </li>
        `);
    });
    
    // 更新在线人数
    $('#userCount').text(users.length);
    $('#onlineCount').text(users.length);
}

/**
 * 发送消息
 */
function sendMessage() {
    const $input = $('#messageInput');
    const content = $input.val().trim();
    
    if (!content) return;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
        alert('连接已断开，请刷新页面重试');
        return;
    }
    
    // 发送消息
    ws.send(JSON.stringify({
        type: 'message',
        content: content
    }));
    
    // 清空输入框
    $input.val('');
    adjustTextareaHeight($input[0]);
}

/**
 * 初始化Emoji选择器
 */
function initEmojiPicker() {
    const $grid = $('#emojiGrid');
    
    emojis.forEach(function(emoji) {
        $grid.append(`<span class="emoji-item">${emoji}</span>`);
    });
}

/**
 * 绑定事件
 */
function bindEvents() {
    // 发送按钮
    $('#sendBtn').on('click', sendMessage);
    
    // 回车发送（Shift+Enter换行）
    $('#messageInput').on('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // 输入框自动调整高度
    $('#messageInput').on('input', function() {
        adjustTextareaHeight(this);
    });
    
    // Emoji按钮
    $('#emojiBtn').on('click', function() {
        $('#emojiPicker').toggleClass('show');
        $('#atMenu').removeClass('show');
    });
    
    // 关闭Emoji选择器
    $('#closeEmoji').on('click', function() {
        $('#emojiPicker').removeClass('show');
    });
    
    // 选择Emoji
    $(document).on('click', '.emoji-item', function() {
        const emoji = $(this).text();
        const $input = $('#messageInput');
        const cursorPos = $input[0].selectionStart;
        const text = $input.val();
        
        $input.val(text.slice(0, cursorPos) + emoji + text.slice(cursorPos));
        $input.focus();
        $input[0].selectionStart = $input[0].selectionEnd = cursorPos + emoji.length;
        
        $('#emojiPicker').removeClass('show');
    });
    
    // @功能按钮
    $('#atBtn, #atMenuBtn').on('click', function() {
        $('#atMenu').toggleClass('show');
        $('#emojiPicker').removeClass('show');
    });
    
    // 关闭@菜单
    $('#closeAtMenu').on('click', function() {
        $('#atMenu').removeClass('show');
    });
    
    // 选择@功能
    $('.at-item').on('click', function() {
        const atText = '@' + $(this).data('at') + ' ';
        const $input = $('#messageInput');
        const cursorPos = $input[0].selectionStart;
        const text = $input.val();
        
        $input.val(text.slice(0, cursorPos) + atText + text.slice(cursorPos));
        $input.focus();
        $input[0].selectionStart = $input[0].selectionEnd = cursorPos + atText.length;
        
        $('#atMenu').removeClass('show');
    });
    
    // 点击用户列表中的用户，@该用户
    $(document).on('click', '.user-list li', function() {
        const username = $(this).data('user');
        if (username && username !== currentUser) {
            const atText = '@' + username + ' ';
            const $input = $('#messageInput');
            $input.val($input.val() + atText);
            $input.focus();
        }
        
        // 移动端关闭侧边栏
        if ($(window).width() <= 768) {
            closeSidebar();
        }
    });
    
    // 历史记录按钮
    $('#historyBtn').on('click', function() {
        $('#historyModal').addClass('show');
    });
    
    // 关闭历史记录弹窗
    $('#closeHistoryModal').on('click', function() {
        $('#historyModal').removeClass('show');
    });
    
    // 点击弹窗外部关闭
    $('#historyModal').on('click', function(e) {
        if (e.target === this) {
            $(this).removeClass('show');
        }
    });
    
    // 退出按钮
    $('#logoutBtn').on('click', function() {
        logout();
    });
    
    // 移动端菜单按钮
    $('#menuBtn').on('click', function() {
        openSidebar();
    });
    
    // 侧边栏关闭按钮
    $('#sidebarToggle').on('click', function() {
        closeSidebar();
    });
    
    // 点击消息区域关闭弹出菜单
    $('#messagesContainer').on('click', function() {
        $('#emojiPicker').removeClass('show');
        $('#atMenu').removeClass('show');
    });
    
    // 窗口大小改变时处理
    $(window).on('resize', function() {
        if ($(window).width() > 768) {
            $('#sidebar').removeClass('show');
            $('.sidebar-overlay').removeClass('show');
        }
    });
}

/**
 * 打开侧边栏（移动端）
 */
function openSidebar() {
    $('#sidebar').addClass('show');
    
    // 添加遮罩层
    if (!$('.sidebar-overlay').length) {
        $('body').append('<div class="sidebar-overlay"></div>');
    }
    $('.sidebar-overlay').addClass('show').on('click', closeSidebar);
}

/**
 * 关闭侧边栏（移动端）
 */
function closeSidebar() {
    $('#sidebar').removeClass('show');
    $('.sidebar-overlay').removeClass('show');
}

/**
 * 退出登录
 */
function logout() {
    // 发送离开消息
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'leave'
        }));
        ws.close();
    }
    
    // 清除登录信息
    sessionStorage.removeItem('oo_nickname');
    sessionStorage.removeItem('oo_server');
    
    // 跳转到登录页
    window.location.href = '/';
}

/**
 * 显示连接状态
 */
function showConnectionStatus(status, text) {
    const $status = $('#connectionStatus');
    $status.removeClass('connected disconnected').addClass('show');
    
    if (status === 'connected') {
        $status.addClass('connected');
        $('.status-icon').text('✓');
    } else if (status === 'disconnected') {
        $status.addClass('disconnected');
        $('.status-icon').text('✕');
    } else {
        $('.status-icon').text('🔄');
    }
    
    $('.status-text').text(text);
}

/**
 * 隐藏连接状态
 */
function hideConnectionStatus() {
    $('#connectionStatus').removeClass('show');
}

/**
 * 滚动到底部
 */
function scrollToBottom() {
    const $container = $('#messagesContainer');
    $container.scrollTop($container[0].scrollHeight);
}

/**
 * 调整文本框高度
 */
function adjustTextareaHeight(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 100) + 'px';
}

/**
 * HTML转义
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// 页面关闭前发送离开消息
$(window).on('beforeunload', function() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'leave'
        }));
    }
});
