"""
数据抓取模块 - 百度搜索舆情数据采集
"""
import requests
from bs4 import BeautifulSoup
import re
import json
import time
import random
from urllib.parse import quote, urljoin, urlparse


def clean_text(text):
    """
    清理文本中的脏数据
    
    Args:
        text: 原始文本
        
    Returns:
        str: 清理后的文本
    """
    if not text:
        return ''
    
    # 移除HTML标签残留
    text = re.sub(r'<[^>]+>', '', text)
    
    # 移除HTML实体
    text = re.sub(r'&[a-zA-Z]+;|&#\d+;', ' ', text)
    
    # 移除特殊Unicode字符（保留中文、英文、数字、常用标点）
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
    
    # 移除零宽字符
    text = re.sub(r'[\u200b-\u200f\u2028-\u202f\u205f-\u206f\ufeff]', '', text)
    
    # 规范化空白字符（多个空格/换行/制表符合并为单个空格）
    text = re.sub(r'[\s\t\n\r]+', ' ', text)
    
    # 移除首尾空白
    text = text.strip()
    
    # 移除重复标点
    text = re.sub(r'([。，！？、；：,.!?;:]){2,}', r'\1', text)
    
    # 移除百度搜索常见的干扰文本
    noise_patterns = [
        r'^百度快照$',
        r'^广告$',
        r'百度为您找到相关结果.*',
        r'\d+条相关',
        r'查看更多.*',
        r'展开全部',
        r'^\d+年\d+月\d+日\s*[-—]?\s*',  # 移除开头的日期
    ]
    for pattern in noise_patterns:
        text = re.sub(pattern, '', text)
    
    return text.strip()


def clean_url(url):
    """
    清理URL
    
    Args:
        url: 原始URL
        
    Returns:
        str: 清理后的URL
    """
    if not url:
        return ''
    
    url = url.strip()
    
    # 移除URL中的空白字符
    url = re.sub(r'\s+', '', url)
    
    # 确保URL格式正确
    if url and not url.startswith(('http://', 'https://')):
        if url.startswith('//'):
            url = 'https:' + url
    
    return url


def clean_source(source):
    """
    清理来源信息
    
    Args:
        source: 原始来源
        
    Returns:
        str: 清理后的来源
    """
    if not source:
        return ''
    
    source = clean_text(source)
    
    # 移除来源中常见的干扰内容
    source = re.sub(r'https?://[^\s]*', '', source)  # 移除URL
    source = re.sub(r'www\.[^\s]*', '', source)  # 移除www开头的域名
    source = re.sub(r'\d{4}[-/]\d{1,2}[-/]\d{1,2}', '', source)  # 移除日期
    source = re.sub(r'\d+小时前|\d+分钟前|\d+天前|昨天|前天', '', source)  # 移除相对时间
    
    # 只保留来源名称（通常在最前面）
    source = source.split('-')[0].split('_')[0].split('|')[0]
    
    return source.strip()


def clean_result_item(item):
    """
    清理单个搜索结果项的所有字段
    
    Args:
        item: 原始结果项字典
        
    Returns:
        dict: 清理后的结果项
    """
    if not item:
        return None
    
    cleaned = {
        'title': clean_text(item.get('title', '')),
        'summary': clean_text(item.get('summary', '')),
        'cover': clean_url(item.get('cover', '')),
        'cover_fallback': clean_url(item.get('cover_fallback', '')),
        'url': clean_url(item.get('url', '')),
        'source': clean_source(item.get('source', ''))
    }
    
    # 如果标题和摘要相同，清空摘要避免重复
    if cleaned['title'] and cleaned['summary'] == cleaned['title']:
        cleaned['summary'] = ''
    
    # 截断过长的摘要
    if len(cleaned['summary']) > 500:
        cleaned['summary'] = cleaned['summary'][:500] + '...'
    
    return cleaned


class BaiduCrawler:
    """多引擎新闻搜索数据抓取器（搜狗+360备用）"""
    
    USER_AGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    ]
    
    def __init__(self):
        self.current_ua = random.choice(self.USER_AGENTS)
    
    def _get_headers(self):
        """获取请求头"""
        return {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Connection': 'keep-alive',
            'User-Agent': self.current_ua,
        }
    
    def search(self, keyword, page=1, page_size=10):
        """
        搜索关键字并返回新闻结果（多引擎备用）
        
        Args:
            keyword: 搜索关键字
            page: 页码，从1开始
            page_size: 每页结果数量
            
        Returns:
            list: 搜索结果列表，每项包含：
                - title: 标题
                - summary: 概要
                - cover: 封面图片URL
                - url: 原始URL
                - source: 来源
        """
        # 尝试搜狗新闻
        results = self._search_sogou(keyword, page)
        
        # 如果搜狗没有结果，尝试360搜索
        if not results:
            results = self._search_360(keyword, page)
        
        return results
    
    def _search_sogou(self, keyword, page=1):
        """搜狗新闻搜索"""
        results = []
        
        try:
            params = {'query': keyword, 'mode': '1', 'page': page}
            time.sleep(random.uniform(0.3, 0.8))
            
            response = requests.get(
                "https://news.sogou.com/news",
                params=params,
                headers=self._get_headers(),
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            news_items = soup.select('div.vrwrap, div.news-item, div.rb')
            
            seen_titles = set()
            for item_div in news_items:
                try:
                    item = self._parse_sogou_item(item_div)
                    if item and item['title'] not in seen_titles:
                        seen_titles.add(item['title'])
                        item = clean_result_item(item)
                        if item:
                            results.append(item)
                except:
                    continue
        except:
            pass
        
        return results
    
    def _search_360(self, keyword, page=1):
        """360搜索"""
        results = []
        
        try:
            params = {'q': keyword, 'pn': page, 'ie': 'utf-8'}
            time.sleep(random.uniform(0.3, 0.8))
            
            response = requests.get(
                "https://www.so.com/s",
                params=params,
                headers=self._get_headers(),
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            result_items = soup.select('li.res-list, div.result')
            
            seen_titles = set()
            for item_div in result_items:
                try:
                    item = self._parse_360_item(item_div)
                    if item and item['title'] not in seen_titles:
                        seen_titles.add(item['title'])
                        item = clean_result_item(item)
                        if item:
                            results.append(item)
                except:
                    continue
        except:
            pass
        
        return results
    
    def _parse_sogou_item(self, item_div):
        """解析搜狗新闻结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        title_elem = item_div.select_one('h3 a, a.news-title')
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            href = title_elem.get('href', '')
            item['url'] = 'https://news.sogou.com' + href if href.startswith('/link') else href
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        summary_elem = item_div.select_one('.ft, .news-txt, p.txt-info')
        if summary_elem:
            item['summary'] = summary_elem.get_text(strip=True)
        
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            item['cover'] = 'https://www.sogou.com/favicon.ico'
        
        source_elem = item_div.select_one('.news-from, cite, span.citeurl')
        if source_elem:
            item['source'] = source_elem.get_text(strip=True).split(' ')[0].split('\xa0')[0]
        if not item['source']:
            item['source'] = '网络新闻'
        
        return item
    
    def _parse_360_item(self, item_div):
        """解析360搜索结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        title_elem = item_div.select_one('h3 a, a[href]')
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            href = title_elem.get('href', '') or title_elem.get('data-url', '')
            item['url'] = href if href.startswith('http') else 'https://www.so.com' + href
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        summary_elem = item_div.select_one('.res-desc, .res-rich, p')
        if summary_elem:
            item['summary'] = summary_elem.get_text(strip=True)
        
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            item['cover'] = 'https://www.so.com/favicon.ico'
        
        # 从URL提取来源
        if item['url']:
            try:
                parsed = urlparse(item['url'])
                if parsed.netloc and 'so.com' not in parsed.netloc:
                    item['source'] = parsed.netloc.replace('www.', '')
            except:
                pass
        if not item['source']:
            item['source'] = '网络来源'
        
        return item
    
# 来源类型匹配规则
SOURCE_TYPE_PATTERNS = {
    'baike': ['baike.baidu.com', 'baike.so.com', 'baike.sogou.com', 'wiki', '百科'],
    'news': ['news', 'sina.com', 'sohu.com', 'qq.com', '163.com', 'ifeng.com', 'people.com', 
             'xinhua', 'cctv', 'chinanews', '新闻', '资讯', '报'],
    'gov': ['.gov.cn', '.gov.com', '政府', '政务', '人民政府'],
    'zhihu': ['zhihu.com', '知乎'],
    'weibo': ['weibo.com', 'weibo.cn', '微博'],
    'video': ['bilibili', 'youku', 'iqiyi', 'v.qq.com', 'douyin', 'kuaishou', 
              'video', '视频', 'tv.'],
    'map': ['map.', 'ditu.', 'amap.com', 'map.qq.com', 'map.baidu.com', '地图'],
}


def match_source_type(source, url, source_type):
    """
    检查来源是否匹配指定类型
    
    Args:
        source: 来源字符串
        url: URL字符串
        source_type: 来源类型
        
    Returns:
        bool: 是否匹配
    """
    if not source_type:
        return True  # 不筛选
    
    if source_type == 'other':
        # 其他来源：不匹配任何已知类型
        for patterns in SOURCE_TYPE_PATTERNS.values():
            for pattern in patterns:
                if pattern.lower() in source.lower() or pattern.lower() in url.lower():
                    return False
        return True
    
    patterns = SOURCE_TYPE_PATTERNS.get(source_type, [])
    for pattern in patterns:
        if pattern.lower() in source.lower() or pattern.lower() in url.lower():
            return True
    return False


def crawl_baidu(keyword, count=10, source_type=''):
    """
    爬取搜索结果的便捷函数
    
    Args:
        keyword: 搜索关键字
        count: 需要采集的条数
        source_type: 来源类型筛选（baike/news/gov/zhihu/weibo/video/map/other）
        
    Returns:
        list: 搜索结果列表，每项包含：
            - title: 标题
            - summary: 概要
            - cover: 封面图片URL
            - url: 原始URL
            - source: 来源
    """
    crawler = BaiduCrawler()
    all_results = []
    page = 1
    max_pages = 20  # 增加最大页数以便筛选
    
    while len(all_results) < count and page <= max_pages:
        results = crawler.search(keyword, page=page)
        
        if not results:
            break  # 没有更多结果了
        
        # 根据来源类型筛选
        for item in results:
            if match_source_type(item.get('source', ''), item.get('url', ''), source_type):
                all_results.append(item)
                if len(all_results) >= count:
                    break
        
        page += 1
        
        if len(all_results) < count:
            time.sleep(random.uniform(0.5, 1.0))  # 页面间延迟
    
    # 返回指定数量的结果
    return all_results[:count]


def deep_crawl(url):
    """
    深度采集单个URL的内容
    
    Args:
        url: 要采集的URL
        
    Returns:
        dict: 包含content(正文)、summary(摘要)、real_url(真实URL)的字典
    """
    result = {
        'content': '',
        'summary': '',
        'real_url': url
    }
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        }
        
        # 发送请求，允许重定向以获取真实URL
        response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        result['real_url'] = response.url  # 获取重定向后的真实URL
        response.encoding = response.apparent_encoding or 'utf-8'
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 移除脚本和样式
        for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe', 'noscript']):
            tag.decompose()
        
        # 尝试获取正文内容
        content = ''
        
        # 常见的正文容器选择器
        content_selectors = [
            'article',
            '.article-content',
            '.post-content',
            '.entry-content',
            '.content',
            '.main-content',
            '#content',
            '.article',
            '.post',
            'main',
            '.text',
            '.body'
        ]
        
        for selector in content_selectors:
            elem = soup.select_one(selector)
            if elem:
                content = elem.get_text(separator='\n', strip=True)
                if len(content) > 100:
                    break
        
        # 如果没找到，尝试获取body中最大的文本块
        if not content or len(content) < 100:
            body = soup.find('body')
            if body:
                # 获取所有段落
                paragraphs = body.find_all(['p', 'div'])
                texts = []
                for p in paragraphs:
                    text = p.get_text(strip=True)
                    if len(text) > 50:  # 只保留较长的段落
                        texts.append(text)
                content = '\n'.join(texts)
        
        # 清理内容
        content = clean_text(content)
        
        # 截断过长内容
        if len(content) > 5000:
            content = content[:5000] + '...'
        
        result['content'] = content
        
        # 生成摘要（取前300字）
        if content:
            summary = content[:300]
            if len(content) > 300:
                summary += '...'
            result['summary'] = summary
            
    except Exception as e:
        print(f"深度采集失败 {url}: {e}")
    
    return result


def deep_crawl_batch(urls):
    """
    批量深度采集多个URL
    
    Args:
        urls: URL列表
        
    Returns:
        list: 采集结果列表
    """
    results = []
    for url in urls:
        result = deep_crawl(url)
        results.append(result)
        time.sleep(random.uniform(0.5, 1))  # 请求间延迟
    return results


# 测试代码
if __name__ == '__main__':
    keyword = "西昌"
    print(f"正在搜索关键字: {keyword}")
    print("-" * 50)
    
    results = crawl_baidu(keyword, pages=1)
    
    for i, item in enumerate(results, 1):
        print(f"\n【结果 {i}】")
        print(f"标题: {item['title']}")
        print(f"概要: {item['summary'][:100]}..." if len(item['summary']) > 100 else f"概要: {item['summary']}")
        print(f"封面: {item['cover']}")
        print(f"原始URL: {item['url']}")
        print(f"来源: {item['source']}")
    
    print(f"\n共获取 {len(results)} 条结果")
