/**
 * OO聊天室 - 登录页面脚本
 */

$(document).ready(function() {
    // 加载服务器配置
    loadServerConfig();
    
    // 登录表单提交
    $('#loginForm').on('submit', function(e) {
        e.preventDefault();
        handleLogin();
    });
    
    // 输入框焦点效果
    $('input, select').on('focus', function() {
        $(this).parent().addClass('focused');
    }).on('blur', function() {
        $(this).parent().removeClass('focused');
    });
});

/**
 * 加载服务器配置
 */
function loadServerConfig() {
    $.ajax({
        url: '/api/config',
        method: 'GET',
        dataType: 'json',
        success: function(config) {
            const $server = $('#server');
            $server.empty();
            $server.append('<option value="">选择服务器...</option>');
            
            if (config.servers && config.servers.length > 0) {
                config.servers.forEach(function(server) {
                    $server.append(
                        $('<option></option>')
                            .val(server.url)
                            .text(server.name)
                    );
                });
                // 默认选择第一个服务器
                if (config.servers.length > 0) {
                    $server.val(config.servers[0].url);
                }
            }
        },
        error: function() {
            showError('无法加载服务器配置，请刷新页面重试');
        }
    });
}

/**
 * 处理登录
 */
function handleLogin() {
    const nickname = $('#nickname').val().trim();
    const password = $('#password').val();
    const server = $('#server').val();
    
    // 前端验证
    if (!nickname) {
        showError('请输入昵称');
        $('#nickname').focus();
        return;
    }
    
    if (nickname.length > 20) {
        showError('昵称不能超过20个字符');
        $('#nickname').focus();
        return;
    }
    
    if (!password) {
        showError('请输入密码');
        $('#password').focus();
        return;
    }
    
    if (!server) {
        showError('请选择服务器');
        $('#server').focus();
        return;
    }
    
    // 显示加载状态
    const $btn = $('.login-btn');
    $btn.addClass('loading');
    hideError();
    
    // 发送登录请求
    $.ajax({
        url: '/api/login',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            nickname: nickname,
            password: password,
            server: server
        }),
        success: function(response) {
            $btn.removeClass('loading');
            
            if (response.success) {
                // 存储登录信息到sessionStorage
                sessionStorage.setItem('oo_nickname', nickname);
                sessionStorage.setItem('oo_server', server);
                
                // 跳转到聊天室
                window.location.href = '/chat';
            } else {
                showError(response.message || '登录失败');
            }
        },
        error: function() {
            $btn.removeClass('loading');
            showError('网络错误，请稍后重试');
        }
    });
}

/**
 * 显示错误消息
 */
function showError(message) {
    const $errorMsg = $('#errorMsg');
    $errorMsg.text(message).addClass('show');
}

/**
 * 隐藏错误消息
 */
function hideError() {
    $('#errorMsg').removeClass('show');
}
