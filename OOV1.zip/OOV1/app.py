"""
veichat - Flask + WebSocket 后端服务
"""
import json
import os
import re
import requests
import threading
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from flask_sock import Sock

# 成小理 AI 配置
AI_CONFIG = {
    'api_key': 'sk-fnxxvbyghvztultccxvotxmerlelzdvwpwrtubifiyajgqyc',
    'model': 'Qwen/Qwen3-8B',
    'api_url': 'https://api.siliconflow.cn/v1/chat/completions'
}

app = Flask(__name__)
app.config['SECRET_KEY'] = 'oo-chatroom-secret-key'
sock = Sock(app)

# 存储在线用户和WebSocket连接
online_users = {}  # {nickname: websocket}
user_connections = {}  # {websocket: nickname}

# 加载配置文件
def load_config():
    config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

# 广播消息给所有在线用户
def broadcast_message(message, exclude_ws=None):
    disconnected = []
    for nickname, ws in online_users.items():
        if ws != exclude_ws:
            try:
                ws.send(json.dumps(message, ensure_ascii=False))
            except Exception:
                disconnected.append(nickname)
    # 清理断开的连接
    for nickname in disconnected:
        if nickname in online_users:
            del online_users[nickname]

# 发送在线用户列表
def send_user_list():
    user_list = list(online_users.keys())
    message = {
        'type': 'user_list',
        'users': user_list,
        'count': len(user_list)
    }
    broadcast_message(message)

# 调用成小理AI
def call_xiaoli_ai(user_question, callback):
    """异步调用成小理AI并通过回调返回结果"""
    def ai_request():
        try:
            headers = {
                'Authorization': f'Bearer {AI_CONFIG["api_key"]}',
                'Content-Type': 'application/json'
            }
            
            data = {
                'model': AI_CONFIG['model'],
                'messages': [
                    {
                        'role': 'system',
                        'content': '你是成小理，一个友好、智能的AI助手。你的回答要简洁、有帮助、有趣味。请用中文回答。'
                    },
                    {
                        'role': 'user',
                        'content': user_question
                    }
                ],
                'max_tokens': 1000,
                'temperature': 0.7
            }
            
            response = requests.post(
                AI_CONFIG['api_url'],
                headers=headers,
                json=data,
                timeout=30
            )
            
            if response.status_code == 200:
                result = response.json()
                ai_reply = result['choices'][0]['message']['content']
                # 清理思考过程标签
                ai_reply = re.sub(r'<think>.*?</think>', '', ai_reply, flags=re.DOTALL).strip()
                callback(True, ai_reply)
            else:
                callback(False, f'AI服务暂时不可用 (错误码: {response.status_code})')
                
        except requests.Timeout:
            callback(False, '成小理思考超时了，请稍后再试~')
        except Exception as e:
            callback(False, f'成小理遇到了一点问题: {str(e)}')
    
    # 在新线程中执行AI请求
    thread = threading.Thread(target=ai_request)
    thread.start()

# 音乐API配置 (使用52vmy随机音乐API)
MUSIC_API_URL = 'https://api.52vmy.cn/api/music/wy/rand'

# 获取随机音乐
def get_random_music(callback):
    """异步获取随机音乐"""
    def music_request():
        try:
            print(f'[音乐API] 请求中...')
            response = requests.get(MUSIC_API_URL, timeout=15)
            if response.status_code == 200:
                result = response.json()
                print(f'[音乐API] 返回数据: {result}')
                if result.get('code') == 200 and result.get('data'):
                    music_data = result['data']
                    callback(True, {
                        'name': music_data.get('song', '未知歌曲'),
                        'singer': music_data.get('singer', '未知歌手'),
                        'url': music_data.get('Music', ''),
                        'image': music_data.get('cover', '')
                    })
                    return
        except Exception as e:
            print(f'[音乐API] 失败: {e}')
        
        callback(False, '音乐API暂时不可用，请稍后再试~')
    
    # 在新线程中执行请求
    thread = threading.Thread(target=music_request)
    thread.start()

# 搜索音乐 (使用网易云音乐API)
def search_music(keyword, callback):
    """异步搜索音乐"""
    def search_request():
        try:
            print(f'[搜歌] 搜索: {keyword}')
            # 搜索歌曲
            search_url = f'http://music.163.com/api/search/get/web?s={keyword}&type=1&limit=1'
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            response = requests.get(search_url, timeout=10, headers=headers)
            
            if response.status_code == 200:
                result = response.json()
                print(f'[搜歌] 搜索结果: {result}')
                if result.get('code') == 200 and result.get('result', {}).get('songs'):
                    song = result['result']['songs'][0]
                    song_id = song['id']
                    song_name = song['name']
                    artist_name = song['artists'][0]['name'] if song.get('artists') else '未知歌手'
                    album = song.get('album', {})
                    cover = f"http://music.163.com/api/album/{album.get('id')}?id={album.get('id')}"
                    
                    # 获取封面图片
                    cover_url = ''
                    if album.get('picId'):
                        cover_url = f"https://p1.music.126.net/{album.get('picId')}/{album.get('picId')}.jpg"
                    
                    # 构建播放链接
                    music_url = f"http://music.163.com/song/media/outer/url?id={song_id}"
                    
                    callback(True, {
                        'name': song_name,
                        'singer': artist_name,
                        'url': music_url,
                        'image': cover_url or 'https://p1.music.126.net/6y-UleORITEDbvrOLV0Q8A==/5639395138885805.jpg'
                    })
                    return
                else:
                    callback(False, f'未找到"{keyword}"相关歌曲')
                    return
        except Exception as e:
            print(f'[搜歌] 失败: {e}')
        
        callback(False, '搜索失败，请稍后再试~')
    
    thread = threading.Thread(target=search_request)
    thread.start()

# 新闻API配置 (每日60秒读懂世界)
NEWS_API_URL = 'https://api.pearktrue.cn/api/60s/'

# 获取新闻
def get_news(callback):
    """异步获取新闻"""
    def news_request():
        try:
            print(f'[新闻API] 请求中...')
            response = requests.get(NEWS_API_URL, timeout=10)
            if response.status_code == 200:
                result = response.json()
                print(f'[新闻API] 返回数据条数: {len(result.get("data", []))}')
                
                if result.get('code') == 200 and result.get('data'):
                    # 将字符串列表转换为新闻对象列表
                    news_list = []
                    for item in result['data'][:15]:
                        # 清理序号前缀
                        title = item
                        if title and len(title) > 2 and title[0].isdigit():
                            # 移除开头的数字序号
                            import re
                            title = re.sub(r'^[\d、\.]+', '', title).strip()
                        news_list.append({'title': title})
                    
                    if news_list:
                        callback(True, news_list)
                        return
                
                callback(False, '暂无新闻数据')
                return
        except Exception as e:
            print(f'[新闻API] 失败: {e}')
            callback(False, f'获取新闻失败，请稍后再试~')
    
    thread = threading.Thread(target=news_request)
    thread.start()

# 天气API (使用wttr.in免费API)
def get_weather(city, callback):
    """异步获取天气信息"""
    def weather_request():
        try:
            # 使用wttr.in API
            url = f'https://wttr.in/{city}?format=j1&lang=zh'
            response = requests.get(url, timeout=10, headers={'Accept-Language': 'zh-CN'})
            
            if response.status_code == 200:
                data = response.json()
                current = data.get('current_condition', [{}])[0]
                
                # 天气描述映射
                weather_map = {
                    'Sunny': '晴天 ☀️',
                    'Clear': '晴朗 🌙',
                    'Partly cloudy': '多云 ⛅',
                    'Cloudy': '阴天 ☁️',
                    'Overcast': '阴天 ☁️',
                    'Mist': '薄雾 🌫️',
                    'Fog': '雾 🌫️',
                    'Light rain': '小雨 🌧️',
                    'Moderate rain': '中雨 🌧️',
                    'Heavy rain': '大雨 🌧️',
                    'Light snow': '小雪 🌨️',
                    'Moderate snow': '中雪 🌨️',
                    'Heavy snow': '大雪 🌨️',
                    'Thunderstorm': '雷暴 ⛈️',
                    'Patchy rain possible': '可能有雨 🌦️'
                }
                
                weather_desc = current.get('weatherDesc', [{}])[0].get('value', 'Unknown')
                weather_zh = weather_map.get(weather_desc, weather_desc)
                
                # 获取未来天气
                forecast = []
                weather_data = data.get('weather', [])
                for day in weather_data[:3]:
                    forecast.append({
                        'date': day.get('date', ''),
                        'max_temp': day.get('maxtempC', ''),
                        'min_temp': day.get('mintempC', ''),
                        'desc': day.get('hourly', [{}])[4].get('weatherDesc', [{}])[0].get('value', '')
                    })
                
                callback(True, {
                    'city': city,
                    'temp': current.get('temp_C', 'N/A'),
                    'feels_like': current.get('FeelsLikeC', 'N/A'),
                    'weather': weather_zh,
                    'humidity': current.get('humidity', 'N/A'),
                    'wind_speed': current.get('windspeedKmph', 'N/A'),
                    'wind_dir': current.get('winddir16Point', ''),
                    'visibility': current.get('visibility', 'N/A'),
                    'uv_index': current.get('uvIndex', 'N/A'),
                    'forecast': forecast
                })
                return
                
        except Exception as e:
            print(f'[天气API] 失败: {e}')
        
        callback(False, '获取天气信息失败，请检查城市名称~')
    
    thread = threading.Thread(target=weather_request)
    thread.start()

# 星座运势 (使用AI生成)
HOROSCOPE_SIGNS = ['白羊座', '金牛座', '双子座', '巨蟹座', '狮子座', '处女座', 
                   '天秤座', '天蝎座', '射手座', '摩羯座', '水瓶座', '双鱼座']

def get_horoscope(sign, callback):
    """异步获取星座运势"""
    def horoscope_request():
        try:
            # 使用AI生成星座运势
            headers = {
                'Authorization': f'Bearer {AI_CONFIG["api_key"]}',
                'Content-Type': 'application/json'
            }
            
            today = datetime.now().strftime('%Y年%m月%d日')
            prompt = f"""请为{sign}生成今日({today})的星座运势，包含以下内容，用JSON格式返回：
{{
    "overall": "综合运势评分(1-5星)",
    "love": "爱情运势评分(1-5星)", 
    "career": "事业运势评分(1-5星)",
    "wealth": "财运评分(1-5星)",
    "health": "健康运势评分(1-5星)",
    "lucky_color": "幸运颜色",
    "lucky_number": "幸运数字",
    "summary": "今日运势总结(50字以内)",
    "advice": "今日建议(30字以内)"
}}
只返回JSON，不要其他内容。"""
            
            data = {
                'model': AI_CONFIG['model'],
                'messages': [
                    {'role': 'system', 'content': '你是一个专业的星座运势分析师，请用JSON格式返回运势信息。'},
                    {'role': 'user', 'content': prompt}
                ],
                'max_tokens': 500,
                'temperature': 0.8
            }
            
            response = requests.post(AI_CONFIG['api_url'], headers=headers, json=data, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                ai_reply = result['choices'][0]['message']['content']
                # 清理思考过程
                ai_reply = re.sub(r'<think>.*?</think>', '', ai_reply, flags=re.DOTALL).strip()
                # 提取JSON
                json_match = re.search(r'\{[\s\S]*\}', ai_reply)
                if json_match:
                    horoscope_data = json.loads(json_match.group())
                    horoscope_data['sign'] = sign
                    horoscope_data['date'] = today
                    callback(True, horoscope_data)
                    return
                    
        except Exception as e:
            print(f'[星座运势] 失败: {e}')
        
        callback(False, '获取星座运势失败，请稍后再试~')
    
    thread = threading.Thread(target=horoscope_request)
    thread.start()

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/api/config')
def get_config():
    """获取服务器配置"""
    config = load_config()
    return jsonify(config)

@app.route('/api/login', methods=['POST'])
def login():
    """验证登录"""
    data = request.get_json()
    nickname = data.get('nickname', '').strip()
    password = data.get('password', '')
    
    config = load_config()
    
    if not nickname:
        return jsonify({'success': False, 'message': '请输入昵称'})
    
    if len(nickname) > 20:
        return jsonify({'success': False, 'message': '昵称不能超过20个字符'})
    
    if password != config['app']['password']:
        return jsonify({'success': False, 'message': '密码错误'})
    
    if nickname in online_users:
        return jsonify({'success': False, 'message': '该昵称已被使用'})
    
    return jsonify({'success': True, 'message': '登录成功'})

@app.route('/api/history')
def get_history():
    """获取历史记录 - 预留接口"""
    return jsonify({
        'success': False,
        'message': '历史记录功能正在建设中...',
        'data': []
    })

@app.route('/api/at/<service>', methods=['POST'])
def at_service(service):
    """@功能预留接口"""
    services = {
        '成小理': '小理AI助手功能正在开发中...',
        '音乐': '音乐服务功能正在开发中...',
        '电影': '电影推荐功能正在开发中...',
        '天气': '天气查询功能正在开发中...',
        '新闻': '新闻推送功能正在开发中...',
        '小视频': '小视频功能正在开发中...'
    }
    
    response_msg = services.get(service, f'@{service} 功能正在开发中...')
    return jsonify({
        'success': True,
        'service': service,
        'message': response_msg
    })

@sock.route('/ws')
def websocket(ws):
    """WebSocket连接处理"""
    current_user = None
    
    try:
        while True:
            data = ws.receive()
            if data is None:
                break
                
            message = json.loads(data)
            msg_type = message.get('type')
            
            if msg_type == 'join':
                # 用户加入聊天室
                nickname = message.get('nickname')
                if nickname and nickname not in online_users:
                    current_user = nickname
                    online_users[nickname] = ws
                    user_connections[ws] = nickname
                    
                    # 广播用户加入消息
                    join_msg = {
                        'type': 'system',
                        'content': f'{nickname} 加入了聊天室',
                        'timestamp': datetime.now().strftime('%H:%M:%S')
                    }
                    broadcast_message(join_msg)
                    send_user_list()
                    
                    # 发送欢迎消息给当前用户
                    welcome_msg = {
                        'type': 'system',
                        'content': f'欢迎来到veichat，{nickname}！',
                        'timestamp': datetime.now().strftime('%H:%M:%S')
                    }
                    ws.send(json.dumps(welcome_msg, ensure_ascii=False))
                    
            elif msg_type == 'message':
                # 普通聊天消息
                if current_user:
                    content = message.get('content', '')
                    
                    chat_msg = {
                        'type': 'message',
                        'nickname': current_user,
                        'content': content,
                        'timestamp': datetime.now().strftime('%H:%M:%S')
                    }
                    broadcast_message(chat_msg)
                    
                    # 检查@电影功能
                    movie_match = re.search(r'@电影\[([^\]]+)\]', content)
                    if movie_match:
                        video_url = movie_match.group(1)
                        movie_msg = {
                            'type': 'movie',
                            'nickname': current_user,
                            'video_url': video_url,
                            'timestamp': datetime.now().strftime('%H:%M:%S')
                        }
                        broadcast_message(movie_msg)
                    # 检查@成小理功能
                    elif '@成小理' in content:
                        # 提取问题内容（去掉@成小理）
                        question = content.replace('@成小理', '').strip()
                        if not question:
                            question = '你好'
                        
                        # 发送"正在思考"提示
                        thinking_msg = {
                            'type': 'ai_thinking',
                            'timestamp': datetime.now().strftime('%H:%M:%S')
                        }
                        broadcast_message(thinking_msg)
                        
                        # 定义AI回复回调
                        def on_ai_reply(success, reply):
                            ai_msg = {
                                'type': 'ai_reply',
                                'nickname': '成小理',
                                'content': reply,
                                'success': success,
                                'timestamp': datetime.now().strftime('%H:%M:%S')
                            }
                            broadcast_message(ai_msg)
                        
                        # 异步调用AI
                        call_xiaoli_ai(question, on_ai_reply)
                    # 检查@音乐一下功能
                    elif '@音乐一下' in content:
                        # 发送"正在获取"提示
                        loading_msg = {
                            'type': 'music_loading',
                            'timestamp': datetime.now().strftime('%H:%M:%S')
                        }
                        broadcast_message(loading_msg)
                        
                        # 定义音乐回调
                        def on_music_result(success, data):
                            if success:
                                music_msg = {
                                    'type': 'music',
                                    'nickname': current_user,
                                    'name': data['name'],
                                    'singer': data['singer'],
                                    'url': data['url'],
                                    'image': data['image'],
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(music_msg)
                            else:
                                error_msg = {
                                    'type': 'system',
                                    'content': f'[音乐] {data}',
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(error_msg)
                        
                        # 异步获取音乐
                        get_random_music(on_music_result)
                    # 检查@搜歌功能
                    elif '@搜歌' in content:
                        # 提取搜索关键词
                        search_match = re.search(r'@搜歌\[([^\]]+)\]', content)
                        if search_match:
                            keyword = search_match.group(1)
                        else:
                            keyword = content.replace('@搜歌', '').strip()
                        
                        if not keyword:
                            error_msg = {
                                'type': 'system',
                                'content': '[搜歌] 请输入歌曲名，如：@搜歌[稻香]',
                                'timestamp': datetime.now().strftime('%H:%M:%S')
                            }
                            broadcast_message(error_msg)
                        else:
                            # 发送加载提示
                            loading_msg = {
                                'type': 'music_loading',
                                'timestamp': datetime.now().strftime('%H:%M:%S')
                            }
                            broadcast_message(loading_msg)
                            
                            # 定义搜索回调
                            def on_search_result(success, data):
                                if success:
                                    music_msg = {
                                        'type': 'music',
                                        'nickname': current_user,
                                        'name': data['name'],
                                        'singer': data['singer'],
                                        'url': data['url'],
                                        'image': data['image'],
                                        'timestamp': datetime.now().strftime('%H:%M:%S')
                                    }
                                    broadcast_message(music_msg)
                                else:
                                    error_msg = {
                                        'type': 'system',
                                        'content': f'[搜歌] {data}',
                                        'timestamp': datetime.now().strftime('%H:%M:%S')
                                    }
                                    broadcast_message(error_msg)
                            
                            # 异步搜索音乐
                            search_music(keyword, on_search_result)
                    # 检查@天气功能
                    elif '@天气' in content:
                        # 提取城市名称
                        weather_match = re.search(r'@天气\[([^\]]+)\]', content)
                        if weather_match:
                            city = weather_match.group(1)
                        else:
                            # 尝试提取@天气后面的文字
                            city = content.replace('@天气', '').strip()
                            if not city:
                                city = '北京'  # 默认城市
                        
                        # 发送加载提示
                        loading_msg = {
                            'type': 'weather_loading',
                            'city': city,
                            'timestamp': datetime.now().strftime('%H:%M:%S')
                        }
                        broadcast_message(loading_msg)
                        
                        # 定义天气回调
                        def on_weather_result(success, data):
                            if success:
                                weather_msg = {
                                    'type': 'weather',
                                    'nickname': current_user,
                                    'data': data,
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(weather_msg)
                            else:
                                error_msg = {
                                    'type': 'system',
                                    'content': f'[天气] {data}',
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(error_msg)
                        
                        # 异步获取天气
                        get_weather(city, on_weather_result)
                    # 检查@星座功能
                    elif '@星座' in content:
                        # 提取星座名称
                        sign_match = re.search(r'@星座\[([^\]]+)\]', content)
                        if sign_match:
                            sign = sign_match.group(1)
                        else:
                            sign = content.replace('@星座', '').strip()
                            if not sign:
                                sign = '白羊座'
                        
                        # 验证星座名称
                        if sign not in HOROSCOPE_SIGNS:
                            # 尝试添加"座"
                            if sign + '座' in HOROSCOPE_SIGNS:
                                sign = sign + '座'
                            else:
                                error_msg = {
                                    'type': 'system',
                                    'content': f'[星座] 未识别的星座名称，请输入如：白羊座、金牛座等',
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(error_msg)
                                continue
                        
                        # 发送加载提示
                        loading_msg = {
                            'type': 'horoscope_loading',
                            'sign': sign,
                            'timestamp': datetime.now().strftime('%H:%M:%S')
                        }
                        broadcast_message(loading_msg)
                        
                        # 定义星座回调
                        def on_horoscope_result(success, data):
                            if success:
                                horoscope_msg = {
                                    'type': 'horoscope',
                                    'nickname': current_user,
                                    'data': data,
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(horoscope_msg)
                            else:
                                error_msg = {
                                    'type': 'system',
                                    'content': f'[星座] {data}',
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(error_msg)
                        
                        # 异步获取星座运势
                        get_horoscope(sign, on_horoscope_result)
                    # 检查@新闻功能
                    elif '@新闻' in content:
                        # 发送加载提示
                        loading_msg = {
                            'type': 'news_loading',
                            'timestamp': datetime.now().strftime('%H:%M:%S')
                        }
                        broadcast_message(loading_msg)
                        
                        # 定义新闻回调
                        def on_news_result(success, data):
                            if success:
                                news_msg = {
                                    'type': 'news',
                                    'nickname': current_user,
                                    'news_list': data,
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(news_msg)
                            else:
                                error_msg = {
                                    'type': 'system',
                                    'content': f'[新闻] {data}',
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(error_msg)
                        
                        # 异步获取新闻
                        get_news(on_news_result)
                    else:
                        # 检查其他@功能
                        at_keywords = ['@小视频']
                        for keyword in at_keywords:
                            if keyword in content:
                                service = keyword[1:]  # 去掉@符号
                                response_msg = {
                                    'type': 'system',
                                    'content': f'[{service}] 功能正在开发中，敬请期待...',
                                    'timestamp': datetime.now().strftime('%H:%M:%S')
                                }
                                broadcast_message(response_msg)
                                break
                    
            elif msg_type == 'leave':
                # 用户离开
                break
                
    except Exception as e:
        print(f'WebSocket error: {e}')
    finally:
        # 清理用户连接
        if current_user and current_user in online_users:
            del online_users[current_user]
            
            # 广播用户离开消息
            leave_msg = {
                'type': 'system',
                'content': f'{current_user} 离开了聊天室',
                'timestamp': datetime.now().strftime('%H:%M:%S')
            }
            broadcast_message(leave_msg)
            send_user_list()
        
        if ws in user_connections:
            del user_connections[ws]

if __name__ == '__main__':
    print('veichat启动中...')
    print('访问地址: http://localhost:8000')
    app.run(host='0.0.0.0', port=8000, debug=True)
