from flask import Flask, render_template, g, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import sqlite3
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'gov-info-check-system-secret-key-2024'
# 支持代理环境下的Session（IDE预览模式）
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True

DATABASE = 'database.db'


# ==================== 数据库操作 ====================
def get_db():
    """获取数据库连接"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db


@app.teardown_appcontext
def close_connection(exception):
    """关闭数据库连接"""
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    """初始化数据库"""
    with app.app_context():
        db = get_db()
        
        # 角色表
        db.execute('''
            CREATE TABLE IF NOT EXISTS roles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 用户表
        db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                role_id INTEGER DEFAULT 2,
                status INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (role_id) REFERENCES roles (id)
            )
        ''')
        
        # 系统设置表
        db.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL UNIQUE,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 抓取日志表
        db.execute('''
            CREATE TABLE IF NOT EXISTS crawl_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                keyword TEXT NOT NULL,
                result_count INTEGER DEFAULT 0,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # 数据仓表
        db.execute('''
            CREATE TABLE IF NOT EXISTS data_warehouses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # 采集数据表
        db.execute('''
            CREATE TABLE IF NOT EXISTS crawl_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                summary TEXT,
                cover TEXT,
                url TEXT NOT NULL,
                source TEXT,
                content TEXT,
                deep_status INTEGER DEFAULT 0,
                keyword TEXT,
                warehouse_id INTEGER,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (warehouse_id) REFERENCES data_warehouses (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # 采集规则表
        db.execute('''
            CREATE TABLE IF NOT EXISTS crawl_rules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                url_pattern TEXT NOT NULL,
                title_xpath TEXT,
                content_xpath TEXT,
                request_headers TEXT,
                status INTEGER DEFAULT 1,
                description TEXT,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # AI引擎表
        db.execute('''
            CREATE TABLE IF NOT EXISTS ai_engines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                provider TEXT NOT NULL,
                api_url TEXT NOT NULL,
                api_key TEXT NOT NULL,
                model_name TEXT NOT NULL,
                status INTEGER DEFAULT 1,
                description TEXT,
                icon_color TEXT DEFAULT '#1890ff',
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # AI分析历史记录表
        db.execute('''
            CREATE TABLE IF NOT EXISTS ai_analysis_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                analysis_type TEXT NOT NULL,
                data_ids TEXT,
                data_count INTEGER DEFAULT 1,
                result TEXT,
                engine_id INTEGER,
                engine_name TEXT,
                model_name TEXT,
                tokens_used INTEGER DEFAULT 0,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (engine_id) REFERENCES ai_engines (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # AI分析模板表
        db.execute('''
            CREATE TABLE IF NOT EXISTS ai_analysis_templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                analysis_type TEXT NOT NULL,
                prompt_template TEXT NOT NULL,
                description TEXT,
                is_system INTEGER DEFAULT 0,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        db.commit()
        
        # 初始化默认角色
        try:
            db.execute("INSERT INTO roles (id, name, description) VALUES (1, 'admin', '管理员')")
            db.execute("INSERT INTO roles (id, name, description) VALUES (2, 'user', '普通用户')")
            db.commit()
        except sqlite3.IntegrityError:
            pass
        
        # 初始化默认管理员账户 admin/admin123
        try:
            admin_password = generate_password_hash('admin123')
            db.execute("INSERT INTO users (username, password, role_id) VALUES (?, ?, 1)", 
                      ('admin', admin_password))
            db.commit()
        except sqlite3.IntegrityError:
            pass
        
        # 初始化默认系统设置
        try:
            db.execute("INSERT INTO settings (key, value) VALUES ('app_name', '政企智能舆情分析报告生成智能体应用系统')")
            db.execute("INSERT INTO settings (key, value) VALUES ('logo_url', '')")
            db.commit()
        except sqlite3.IntegrityError:
            pass


def get_settings():
    """获取系统设置"""
    db = get_db()
    settings = db.execute('SELECT key, value FROM settings').fetchall()
    return {s['key']: s['value'] for s in settings}


# ==================== 权限装饰器 ====================
def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        if session.get('role_id') != 1:
            flash('权限不足，需要管理员权限', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


# ==================== 上下文处理器 ====================
@app.context_processor
def inject_settings():
    """注入系统设置到模板"""
    try:
        settings = get_settings()
        return {'app_settings': settings}
    except:
        return {'app_settings': {'app_name': '政企智能舆情分析报告生成智能体应用系统', 'logo_url': ''}}


# ==================== 路由 ====================
@app.route('/')
def index():
    """首页 - 重定向到登录或仪表盘"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        remember = request.form.get('remember', False)
        
        if not username or not password:
            return jsonify({'code': 1, 'msg': '请输入用户名和密码'})
        
        db = get_db()
        user = db.execute(
            'SELECT u.*, r.name as role_name FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE u.username = ?',
            (username,)
        ).fetchone()
        
        if user is None:
            return jsonify({'code': 1, 'msg': '用户名不存在'})
        
        if not check_password_hash(user['password'], password):
            return jsonify({'code': 1, 'msg': '密码错误'})
        
        if user['status'] != 1:
            return jsonify({'code': 1, 'msg': '账户已被禁用'})
        
        # 设置session
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['role_id'] = user['role_id']
        session['role_name'] = user['role_name']
        
        if remember:
            session.permanent = True
        
        return jsonify({'code': 0, 'msg': '登录成功', 'url': url_for('dashboard')})
    
    return render_template('login.html')


@app.route('/logout')
def logout():
    """退出登录"""
    session.clear()
    return redirect(url_for('login'))


@app.route('/dashboard')
@login_required
def dashboard():
    """仪表盘/首页"""
    return render_template('dashboard.html')


# ==================== 用户管理 ====================
@app.route('/admin/users')
@admin_required
def admin_users():
    """用户管理页面"""
    return render_template('admin/users.html')


@app.route('/api/users', methods=['GET'])
@admin_required
def api_users_list():
    """获取用户列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    db = get_db()
    offset = (page - 1) * limit
    
    if keyword:
        users = db.execute(
            '''SELECT u.id, u.username, u.role_id, u.status, u.created_at, r.name as role_name 
               FROM users u LEFT JOIN roles r ON u.role_id = r.id 
               WHERE u.username LIKE ? ORDER BY u.id DESC LIMIT ? OFFSET ?''',
            (f'%{keyword}%', limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM users WHERE username LIKE ?', (f'%{keyword}%',)).fetchone()[0]
    else:
        users = db.execute(
            '''SELECT u.id, u.username, u.role_id, u.status, u.created_at, r.name as role_name 
               FROM users u LEFT JOIN roles r ON u.role_id = r.id 
               ORDER BY u.id DESC LIMIT ? OFFSET ?''',
            (limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    
    return jsonify({
        'code': 0,
        'msg': '',
        'count': total,
        'data': [dict(u) for u in users]
    })


@app.route('/api/users', methods=['POST'])
@admin_required
def api_users_add():
    """添加用户"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    role_id = data.get('role_id', 2)
    
    if not username or not password:
        return jsonify({'code': 1, 'msg': '用户名和密码不能为空'})
    
    if len(password) < 6:
        return jsonify({'code': 1, 'msg': '密码长度至少6位'})
    
    db = get_db()
    try:
        db.execute(
            'INSERT INTO users (username, password, role_id) VALUES (?, ?, ?)',
            (username, generate_password_hash(password), role_id)
        )
        db.commit()
        return jsonify({'code': 0, 'msg': '添加成功'})
    except sqlite3.IntegrityError:
        return jsonify({'code': 1, 'msg': '用户名已存在'})


@app.route('/api/users/<int:user_id>', methods=['PUT'])
@admin_required
def api_users_update(user_id):
    """更新用户"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    role_id = data.get('role_id')
    status = data.get('status')
    
    db = get_db()
    
    if username:
        try:
            db.execute('UPDATE users SET username = ? WHERE id = ?', (username, user_id))
        except sqlite3.IntegrityError:
            return jsonify({'code': 1, 'msg': '用户名已存在'})
    
    if password:
        if len(password) < 6:
            return jsonify({'code': 1, 'msg': '密码长度至少6位'})
        db.execute('UPDATE users SET password = ? WHERE id = ?', (generate_password_hash(password), user_id))
    
    if role_id is not None:
        db.execute('UPDATE users SET role_id = ? WHERE id = ?', (role_id, user_id))
    
    if status is not None:
        db.execute('UPDATE users SET status = ? WHERE id = ?', (status, user_id))
    
    db.commit()
    return jsonify({'code': 0, 'msg': '更新成功'})


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@admin_required
def api_users_delete(user_id):
    """删除用户"""
    if user_id == session.get('user_id'):
        return jsonify({'code': 1, 'msg': '不能删除当前登录用户'})
    
    db = get_db()
    db.execute('DELETE FROM users WHERE id = ?', (user_id,))
    db.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


# ==================== 角色管理 ====================
@app.route('/admin/roles')
@admin_required
def admin_roles():
    """角色管理页面"""
    return render_template('admin/roles.html')


@app.route('/api/roles', methods=['GET'])
@admin_required
def api_roles_list():
    """获取角色列表"""
    db = get_db()
    roles = db.execute('SELECT * FROM roles ORDER BY id').fetchall()
    return jsonify({
        'code': 0,
        'msg': '',
        'count': len(roles),
        'data': [dict(r) for r in roles]
    })


# ==================== 系统设置 ====================
@app.route('/admin/settings')
@admin_required
def admin_settings():
    """系统设置页面"""
    return render_template('admin/settings.html')


@app.route('/api/settings', methods=['GET'])
@admin_required
def api_settings_get():
    """获取系统设置"""
    settings = get_settings()
    return jsonify({'code': 0, 'data': settings})


@app.route('/api/settings', methods=['POST'])
@admin_required
def api_settings_update():
    """更新系统设置"""
    data = request.get_json()
    db = get_db()
    
    for key, value in data.items():
        db.execute(
            'INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)',
            (key, value)
        )
    
    db.commit()
    return jsonify({'code': 0, 'msg': '保存成功'})


# ==================== 数据抓取模块 ====================
@app.route('/crawler')
@login_required
def crawler_page():
    """数据抓取页面"""
    return render_template('crawler.html')


@app.route('/api/crawler/search', methods=['POST'])
@login_required
def api_crawler_search():
    """执行数据抓取"""
    from crawler import crawl_baidu
    
    data = request.get_json()
    keyword = data.get('keyword', '').strip()
    count = data.get('count', 10)  # 获取采集条数
    source_type = data.get('source_type', '')  # 来源类型筛选
    
    if not keyword:
        return jsonify({'code': 1, 'msg': '请输入搜索关键字'})
    
    # 限制采集条数范围
    if count < 1:
        count = 10
    elif count > 100:
        count = 100
    
    try:
        results = crawl_baidu(keyword, count=count, source_type=source_type)
        
        # 保存抓取记录到数据库
        db = get_db()
        db.execute(
            'INSERT INTO crawl_logs (keyword, result_count, user_id) VALUES (?, ?, ?)',
            (keyword, len(results), session.get('user_id'))
        )
        db.commit()
        
        return jsonify({
            'code': 0,
            'msg': f'成功抓取 {len(results)} 条数据',
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'抓取失败: {str(e)}'})


@app.route('/api/crawler/logs', methods=['GET'])
@login_required
def api_crawler_logs():
    """获取抓取历史记录"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    offset = (page - 1) * limit
    
    logs = db.execute(
        '''SELECT cl.*, u.username FROM crawl_logs cl 
           LEFT JOIN users u ON cl.user_id = u.id 
           ORDER BY cl.created_at DESC LIMIT ? OFFSET ?''',
        (limit, offset)
    ).fetchall()
    
    total = db.execute('SELECT COUNT(*) FROM crawl_logs').fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(log) for log in logs]
    })


@app.route('/api/warehouse/list', methods=['GET'])
@login_required
def api_warehouse_list():
    """获取数据仓列表"""
    db = get_db()
    warehouses = db.execute(
        '''SELECT dw.*, COUNT(cd.id) as data_count 
           FROM data_warehouses dw 
           LEFT JOIN crawl_data cd ON dw.id = cd.warehouse_id
           WHERE dw.user_id = ?
           GROUP BY dw.id
           ORDER BY dw.created_at DESC''',
        (session.get('user_id'),)
    ).fetchall()
    
    return jsonify({
        'code': 0,
        'data': [dict(w) for w in warehouses]
    })


@app.route('/api/warehouse/create', methods=['POST'])
@login_required
def api_warehouse_create():
    """创建数据仓"""
    data = request.get_json()
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()
    
    if not name:
        return jsonify({'code': 1, 'msg': '请输入数据仓名称'})
    
    try:
        db = get_db()
        # 检查是否已存在同名数据仓
        existing = db.execute(
            'SELECT id FROM data_warehouses WHERE name = ? AND user_id = ?',
            (name, session.get('user_id'))
        ).fetchone()
        
        if existing:
            return jsonify({'code': 1, 'msg': '数据仓名称已存在'})
        
        db.execute(
            'INSERT INTO data_warehouses (name, description, user_id) VALUES (?, ?, ?)',
            (name, description, session.get('user_id'))
        )
        db.commit()
        
        return jsonify({'code': 0, 'msg': '数据仓创建成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'创建失败: {str(e)}'})


@app.route('/api/warehouse/<int:id>', methods=['DELETE'])
@login_required
def api_warehouse_delete(id):
    """删除数据仓"""
    try:
        db = get_db()
        # 先删除数据仓中的数据
        db.execute('DELETE FROM crawl_data WHERE warehouse_id = ?', (id,))
        # 再删除数据仓
        db.execute('DELETE FROM data_warehouses WHERE id = ? AND user_id = ?', 
                   (id, session.get('user_id')))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


@app.route('/api/crawler/deep', methods=['POST'])
@login_required
def api_crawler_deep():
    """深度采集URL内容"""
    from crawler import deep_crawl_batch
    
    data = request.get_json()
    urls = data.get('urls', [])
    
    if not urls:
        return jsonify({'code': 1, 'msg': '请提供要采集的URL'})
    
    try:
        results = deep_crawl_batch(urls)
        return jsonify({
            'code': 0,
            'msg': f'成功深度采集 {len(results)} 条数据',
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'深度采集失败: {str(e)}'})


@app.route('/api/crawler/save', methods=['POST'])
@login_required
def api_crawler_save():
    """保存采集数据到数据仓"""
    data = request.get_json()
    keyword = data.get('keyword', '')
    items = data.get('items', [])
    warehouse_id = data.get('warehouse_id')  # 数据仓ID
    
    if not items:
        return jsonify({'code': 1, 'msg': '请选择要存储的数据'})
    
    if not warehouse_id:
        return jsonify({'code': 1, 'msg': '请选择数据仓'})
    
    try:
        db = get_db()
        
        # 验证数据仓是否存在且属于当前用户
        warehouse = db.execute(
            'SELECT id FROM data_warehouses WHERE id = ? AND user_id = ?',
            (warehouse_id, session.get('user_id'))
        ).fetchone()
        
        if not warehouse:
            return jsonify({'code': 1, 'msg': '数据仓不存在'})
        
        saved_count = 0
        
        for item in items:
            # 优先使用真实URL（深度采集后获取的）
            real_url = item.get('real_url') or item.get('url', '')
            
            # 检查是否已存在于该数据仓（根据URL和warehouse_id判断）
            existing = db.execute(
                'SELECT id FROM crawl_data WHERE url = ? AND warehouse_id = ?',
                (real_url, warehouse_id)
            ).fetchone()
            
            if not existing:
                db.execute(
                    '''INSERT INTO crawl_data 
                       (title, summary, cover, url, source, content, deep_status, keyword, warehouse_id, user_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                    (
                        item.get('title', ''),
                        item.get('summary', ''),
                        item.get('cover', ''),
                        real_url,  # 使用真实URL
                        item.get('source', ''),
                        item.get('content', ''),  # 保存详细内容
                        1 if item.get('_deepStatus') == 1 else 0,
                        keyword,
                        warehouse_id,
                        session.get('user_id')
                    )
                )
                saved_count += 1
        
        db.commit()
        
        return jsonify({
            'code': 0,
            'msg': f'成功存储 {saved_count} 条数据' + (f'，{len(items) - saved_count} 条已存在' if saved_count < len(items) else '')
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'存储失败: {str(e)}'})


@app.route('/api/crawler/data', methods=['GET'])
@login_required
def api_crawler_data():
    """获取已存储的采集数据"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    warehouse_id = request.args.get('warehouse_id', type=int)
    offset = (page - 1) * limit
    
    if warehouse_id:
        data = db.execute(
            '''SELECT cd.*, dw.name as warehouse_name FROM crawl_data cd
               LEFT JOIN data_warehouses dw ON cd.warehouse_id = dw.id
               WHERE cd.warehouse_id = ?
               ORDER BY cd.created_at DESC LIMIT ? OFFSET ?''',
            (warehouse_id, limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM crawl_data WHERE warehouse_id = ?', 
                          (warehouse_id,)).fetchone()[0]
    else:
        data = db.execute(
            '''SELECT cd.*, dw.name as warehouse_name FROM crawl_data cd
               LEFT JOIN data_warehouses dw ON cd.warehouse_id = dw.id
               WHERE cd.user_id = ?
               ORDER BY cd.created_at DESC LIMIT ? OFFSET ?''',
            (session.get('user_id'), limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM crawl_data WHERE user_id = ?',
                          (session.get('user_id'),)).fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(row) for row in data]
    })


@app.route('/api/crawler/data/<int:id>', methods=['DELETE'])
@login_required
def api_crawler_data_delete(id):
    """删除采集数据"""
    try:
        db = get_db()
        db.execute('DELETE FROM crawl_data WHERE id = ?', (id,))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


# ==================== 数据仓库管理模块 ====================
@app.route('/warehouse')
@login_required
def warehouse_page():
    """数据仓库管理页面"""
    return render_template('warehouse.html')


@app.route('/api/warehouse/data', methods=['GET'])
@login_required
def api_warehouse_data():
    """获取数据仓中的数据列表"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    warehouse_id = request.args.get('warehouse_id', type=int)
    keyword = request.args.get('keyword', '').strip()
    offset = (page - 1) * limit
    
    if not warehouse_id:
        return jsonify({'code': 0, 'count': 0, 'data': []})
    
    # 构建查询条件
    conditions = ['cd.warehouse_id = ?']
    params = [warehouse_id]
    
    if keyword:
        conditions.append('(cd.title LIKE ? OR cd.keyword LIKE ?)')
        params.extend([f'%{keyword}%', f'%{keyword}%'])
    
    where_clause = ' AND '.join(conditions)
    
    # 查询数据
    data = db.execute(
        f'''SELECT cd.*, dw.name as warehouse_name FROM crawl_data cd
           LEFT JOIN data_warehouses dw ON cd.warehouse_id = dw.id
           WHERE {where_clause}
           ORDER BY cd.created_at DESC LIMIT ? OFFSET ?''',
        params + [limit, offset]
    ).fetchall()
    
    # 查询总数
    total = db.execute(
        f'SELECT COUNT(*) FROM crawl_data cd WHERE {where_clause}',
        params
    ).fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(row) for row in data]
    })


@app.route('/api/warehouse/data/<int:id>', methods=['GET'])
@login_required
def api_warehouse_data_detail(id):
    """获取单条数据详情"""
    db = get_db()
    data = db.execute(
        '''SELECT cd.*, dw.name as warehouse_name FROM crawl_data cd
           LEFT JOIN data_warehouses dw ON cd.warehouse_id = dw.id
           WHERE cd.id = ?''',
        (id,)
    ).fetchone()
    
    if not data:
        return jsonify({'code': 1, 'msg': '数据不存在'})
    
    return jsonify({'code': 0, 'data': dict(data)})


@app.route('/api/warehouse/data/<int:id>', methods=['PUT'])
@login_required
def api_warehouse_data_update(id):
    """更新数据"""
    data = request.get_json()
    
    try:
        db = get_db()
        
        # 检查数据是否存在
        existing = db.execute('SELECT id FROM crawl_data WHERE id = ?', (id,)).fetchone()
        if not existing:
            return jsonify({'code': 1, 'msg': '数据不存在'})
        
        # 更新数据
        db.execute(
            '''UPDATE crawl_data SET 
               title = ?, source = ?, keyword = ?, url = ?, summary = ?, content = ?
               WHERE id = ?''',
            (
                data.get('title', ''),
                data.get('source', ''),
                data.get('keyword', ''),
                data.get('url', ''),
                data.get('summary', ''),
                data.get('content', ''),
                id
            )
        )
        db.commit()
        
        return jsonify({'code': 0, 'msg': '更新成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'更新失败: {str(e)}'})


@app.route('/api/warehouse/data/<int:id>', methods=['DELETE'])
@login_required
def api_warehouse_data_delete(id):
    """删除单条数据"""
    try:
        db = get_db()
        db.execute('DELETE FROM crawl_data WHERE id = ?', (id,))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


@app.route('/api/warehouse/data/batch-delete', methods=['POST'])
@login_required
def api_warehouse_data_batch_delete():
    """批量删除数据"""
    data = request.get_json()
    ids = data.get('ids', [])
    
    if not ids:
        return jsonify({'code': 1, 'msg': '请选择要删除的数据'})
    
    try:
        db = get_db()
        placeholders = ','.join(['?' for _ in ids])
        db.execute(f'DELETE FROM crawl_data WHERE id IN ({placeholders})', ids)
        db.commit()
        return jsonify({'code': 0, 'msg': f'成功删除 {len(ids)} 条数据'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


@app.route('/api/warehouse/deep-crawl', methods=['POST'])
@login_required
def api_warehouse_deep_crawl():
    """数据仓库深度采集"""
    from crawler import deep_crawl_batch
    
    data = request.get_json()
    items = data.get('items', [])
    
    if not items:
        return jsonify({'code': 1, 'msg': '请选择要深度采集的数据'})
    
    try:
        # 构建ID到URL的映射
        id_to_url = {item['id']: item['url'] for item in items}
        urls = [item['url'] for item in items]
        ids = [item['id'] for item in items]
        
        # 获取所有启用的采集规则
        db = get_db()
        rules = db.execute(
            'SELECT id, name, url_pattern, title_xpath, content_xpath, request_headers FROM crawl_rules WHERE status = 1'
        ).fetchall()
        rules_list = [dict(r) for r in rules]
        
        # 执行深度采集（传入规则）
        results = deep_crawl_batch(urls, rules=rules_list)
        
        # 更新数据库
        db = get_db()
        success_count = 0
        
        # 按顺序处理结果（urls和results顺序一致）
        for i, result in enumerate(results):
            data_id = ids[i]
            content = result.get('content', '')
            real_url = result.get('real_url', urls[i])
            
            if content:
                # 有内容则更新
                db.execute(
                    '''UPDATE crawl_data SET 
                       content = ?, deep_status = 1, url = ?
                       WHERE id = ?''',
                    (content, real_url, data_id)
                )
                success_count += 1
            else:
                # 没有内容也标记为已尝试（deep_status=2表示采集失败）
                db.execute(
                    '''UPDATE crawl_data SET deep_status = 2 WHERE id = ?''',
                    (data_id,)
                )
        
        db.commit()
        
        if success_count == 0:
            return jsonify({
                'code': 0,
                'msg': f'深度采集完成，但未能获取到有效内容（共{len(items)}条）'
            })
        
        return jsonify({
            'code': 0,
            'msg': f'成功深度采集 {success_count}/{len(items)} 条数据'
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'code': 1, 'msg': f'深度采集失败: {str(e)}'})


# ==================== 详细内容采集接口 ====================
@app.route('/api/warehouse/detail-crawl', methods=['POST'])
@login_required
def api_warehouse_detail_crawl():
    """详细内容采集 - 使用规则进行定向解析"""
    from crawler import deep_crawl, match_url_pattern
    
    data = request.get_json()
    items = data.get('items', [])
    
    if not items:
        return jsonify({'code': 1, 'msg': '请选择要采集的数据'})
    
    try:
        db = get_db()
        results = []
        success_count = 0
        
        for item in items:
            data_id = item.get('id')
            url = item.get('url')
            rule_id = item.get('rule_id')
            
            result = {
                'id': data_id,
                'success': False,
                'error': None,
                'rule_updated': False
            }
            
            try:
                # 获取规则
                rule = None
                if rule_id:
                    rule_row = db.execute(
                        'SELECT * FROM crawl_rules WHERE id = ?', (rule_id,)
                    ).fetchone()
                    if rule_row:
                        rule = dict(rule_row)
                
                # 执行采集
                crawl_result = deep_crawl(url, rule=rule)
                content = crawl_result.get('content', '')
                real_url = crawl_result.get('real_url', url)
                
                # 强制保存：只要有内容就保存（降低阈值到10字符）
                if content and len(content.strip()) > 10:
                    # 更新数据库
                    summary = content[:300] + '...' if len(content) > 300 else content
                    db.execute(
                        '''UPDATE crawl_data SET content = ?, summary = ?, 
                           deep_status = 1, url = ? WHERE id = ?''',
                        (content, summary, real_url, data_id)
                    )
                    db.commit()
                    
                    result['success'] = True
                    success_count += 1
                    
                    # 检查是否需要更新规则（如果使用了规则但内容较少，可能需要调整）
                    if rule and len(content) < 200:
                        result['suggestion'] = '内容较少，建议检查XPath规则'
                else:
                    result['error'] = '未获取到有效内容'
                    # 标记采集失败
                    db.execute(
                        'UPDATE crawl_data SET deep_status = 2 WHERE id = ?',
                        (data_id,)
                    )
                    db.commit()
                    
            except Exception as e:
                result['error'] = str(e)
                print(f"详细采集失败 {url}: {e}")
            
            results.append(result)
        
        return jsonify({
            'code': 0,
            'msg': f'采集完成，成功 {success_count}/{len(items)} 条',
            'data': results
        })
        
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'code': 1, 'msg': f'采集失败: {str(e)}'})


@app.route('/api/crawl-rules/suggest', methods=['POST'])
@login_required
def api_crawl_rules_suggest():
    """根据URL自动建议XPath规则"""
    from lxml import etree
    import requests as req
    
    data = request.get_json()
    url = data.get('url', '').strip()
    
    if not url:
        return jsonify({'code': 1, 'msg': '请提供URL'})
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = req.get(url, headers=headers, timeout=10)
        response.encoding = response.apparent_encoding or 'utf-8'
        
        tree = etree.HTML(response.text)
        
        # 常见的内容XPath
        content_xpaths = [
            ('//article', 'article标签'),
            ('//div[contains(@class, "article")]', 'article类'),
            ('//div[contains(@class, "content")]', 'content类'),
            ('//div[contains(@class, "post")]', 'post类'),
            ('//div[@id="content"]', 'content ID'),
            ('//main', 'main标签'),
        ]
        
        suggestions = []
        for xpath, desc in content_xpaths:
            try:
                elements = tree.xpath(xpath)
                if elements:
                    text_len = len(etree.tostring(elements[0], encoding='unicode', method='text'))
                    if text_len > 100:
                        suggestions.append({
                            'xpath': xpath,
                            'description': desc,
                            'text_length': text_len
                        })
            except:
                pass
        
        # 按文本长度排序
        suggestions.sort(key=lambda x: x['text_length'], reverse=True)
        
        return jsonify({
            'code': 0,
            'data': suggestions[:5]  # 返回前5个建议
        })
        
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'分析失败: {str(e)}'})


# ==================== AI分析接口 ====================
def get_enabled_ai_engine():
    """获取启用的AI引擎"""
    db = get_db()
    engine = db.execute('SELECT * FROM ai_engines WHERE status = 1 ORDER BY id LIMIT 1').fetchone()
    return dict(engine) if engine else None


def call_ai_api(engine, prompt, max_tokens=2000):
    """调用AI API"""
    import requests as req
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {engine["api_key"]}'
    }
    
    payload = {
        'model': engine['model_name'],
        'messages': [{'role': 'user', 'content': prompt}],
        'max_tokens': max_tokens,
        'temperature': 0.7
    }
    
    response = req.post(
        engine['api_url'],
        headers=headers,
        json=payload,
        timeout=120
    )
    
    if response.status_code == 200:
        result = response.json()
        # 兼容OpenAI格式
        if 'choices' in result and len(result['choices']) > 0:
            return result['choices'][0]['message']['content']
        return result.get('content', str(result))
    else:
        raise Exception(f'API请求失败: {response.status_code} - {response.text[:200]}')


@app.route('/api/ai/engines/enabled', methods=['GET'])
@login_required
def api_ai_engines_enabled():
    """获取所有启用的AI引擎"""
    db = get_db()
    engines = db.execute('SELECT id, name, provider, model_name, icon_color FROM ai_engines WHERE status = 1').fetchall()
    return jsonify({
        'code': 0,
        'data': [dict(e) for e in engines]
    })


@app.route('/api/ai/analyze', methods=['POST'])
@login_required
def api_ai_analyze():
    """AI分析接口"""
    import requests as req
    
    data = request.get_json()
    data_ids = data.get('ids', [])
    analysis_type = data.get('type', 'summary')  # summary, sentiment, keywords, risk, report
    engine_id = data.get('engine_id')  # 可选指定引擎
    
    # 获取AI引擎
    db = get_db()
    if engine_id:
        engine = db.execute('SELECT * FROM ai_engines WHERE id = ? AND status = 1', (engine_id,)).fetchone()
    else:
        engine = db.execute('SELECT * FROM ai_engines WHERE status = 1 ORDER BY id LIMIT 1').fetchone()
    
    if not engine:
        return jsonify({'code': 1, 'msg': '没有可用的AI引擎，请先在AI引擎管理中添加并启用引擎'})
    
    engine = dict(engine)
    
    # 获取要分析的数据
    if not data_ids:
        return jsonify({'code': 1, 'msg': '请选择要分析的数据'})
    
    placeholders = ','.join(['?' for _ in data_ids])
    items = db.execute(f'SELECT id, title, summary, content, source, url FROM crawl_data WHERE id IN ({placeholders})', data_ids).fetchall()
    
    if not items:
        return jsonify({'code': 1, 'msg': '未找到要分析的数据'})
    
    # 构建分析内容
    content_parts = []
    for item in items:
        item = dict(item)
        text = f"【标题】{item['title']}\n"
        if item.get('summary'):
            text += f"【摘要】{item['summary']}\n"
        if item.get('content'):
            # 截取内容前2000字
            content = item['content'][:2000] if len(item.get('content', '')) > 2000 else item.get('content', '')
            text += f"【正文】{content}\n"
        if item.get('source'):
            text += f"【来源】{item['source']}\n"
        content_parts.append(text)
    
    combined_content = "\n---\n".join(content_parts)
    
    # 根据分析类型构建提示词
    prompts = {
        'summary': f"""你是一位专业的信息分析师。请对以下{len(items)}条信息进行智能摘要分析，生成一份简洁的综合摘要报告。

## 分析要求
1. **核心提炼**：提取每条信息的核心要点，归纳主要内容
2. **主题识别**：识别共同主题和关键信息点
3. **逻辑梳理**：按重要性和相关性组织内容
4. **简洁表达**：用精炼的语言概括，避免冗余

## 输出格式
请使用markdown格式，包含：
- 📋 **总体概述**（1-2句话）
- 🔑 **核心要点**（3-5个要点）
- 📊 **信息分类**（按主题分类）
- 💡 **关键发现**

待分析内容：
{combined_content}""",

        'sentiment': f"""你是一位专业的舆情分析师。请对以下{len(items)}条信息进行深度情感倾向分析。

## 分析维度
1. **逐条分析**：判断每条信息的情感倾向（正面😊/中性😐/负面😟）
2. **情感强度**：评估情感表达的强烈程度（1-5分）
3. **情感分布**：统计整体情感分布比例
4. **关键词识别**：提取情感关键词和敏感词
5. **风险评估**：评估舆情风险等级

## 输出格式（markdown）
- 📊 **情感分布统计**（饼图描述）
- 📝 **逐条分析结果**（表格形式）
- 🔥 **情感热词**
- ⚠️ **风险等级**：低/中/高/严重
- 📈 **情感趋势判断**

待分析内容：
{combined_content}""",

        'keywords': f"""你是一位专业的文本分析师。请对以下{len(items)}条信息进行深度关键词和实体提取。

## 提取任务
1. **核心关键词**：提取最重要的15-20个关键词
2. **命名实体识别**：
   - 👤 人物（政府官员、企业家、专家等）
   - 🏢 机构（政府部门、企业、组织等）
   - 📍 地点（国家、城市、地区等）
   - 📅 时间（日期、时间段等）
   - 💰 数据（金额、比例、数量等）
3. **话题标签**：生成5-10个热点话题标签
4. **词频统计**：按出现频次排序

## 输出格式（markdown）
- 🏷️ **核心关键词云**（按重要性排序）
- 👥 **实体识别结果**（分类展示）
- #️⃣ **话题标签**
- 📊 **词频TOP10**

待分析内容：
{combined_content}""",

        'risk': f"""你是一位资深的舆情风险评估专家。请对以下{len(items)}条信息进行全面的舆情风险评估。

## 评估维度
1. **风险识别**：识别所有潜在风险点和敏感信息
2. **风险分级**：
   - 🟢 低危（一般性信息，无明显风险）
   - 🟡 中危（存在一定争议或敏感性）
   - 🟠 高危（可能引发较大舆论关注）
   - 🔴 严重（可能造成重大负面影响）
3. **传播预测**：分析可能的传播路径和扩散趋势
4. **影响评估**：评估对政府/企业形象的潜在影响
5. **应对建议**：提出具体可行的应对措施

## 输出格式（markdown）
- ⚠️ **风险等级**：[等级] + 评分（1-100分）
- 🎯 **风险点清单**（列表形式）
- 📈 **舆情走向预判**
- 🛡️ **应对策略建议**
- ⏰ **响应时效建议**

待分析内容：
{combined_content}""",

        'report': f"""你是一位专业的舆情分析报告撰写专家。请对以下{len(items)}条信息生成一份完整、专业的舆情分析报告。

## 报告结构要求

### 一、执行摘要
- 用3-5句话概括本次分析的核心发现

### 二、信息概述
- 数据来源分布
- 时间范围
- 主要涉及领域

### 三、核心要点分析
- 提炼3-5个最重要的信息点
- 每个要点配简要说明

### 四、情感分析
- 整体情感倾向分布（正面/中性/负面比例）
- 情感变化趋势
- 关键情感词汇

### 五、关键词与实体
- 核心关键词TOP10
- 重要人物/机构/地点

### 六、风险评估
- 风险等级判定
- 主要风险点
- 潜在影响范围

### 七、趋势预判
- 短期发展趋势（1-3天）
- 中期发展趋势（1-2周）
- 可能的舆论走向

### 八、建议措施
- 即时响应建议
- 中长期应对策略
- 舆论引导建议

## 格式要求
- 使用markdown格式
- 适当使用emoji增强可读性
- 重要内容加粗标注
- 数据尽量用表格呈现

待分析内容：
{combined_content}""",

        'trend': f"""你是一位专业的趋势分析师。请对以下{len(items)}条信息进行深度趋势分析。

## 分析任务
1. **时间线梳理**：按时间顺序梳理事件发展脉络
2. **热度变化**：分析话题热度的变化趋势
3. **传播路径**：分析信息传播的可能路径
4. **趋势预测**：预测未来可能的发展方向

## 输出格式（markdown）
- 📅 **事件时间线**
- 📈 **热度趋势图描述**
- 🔄 **传播路径分析**
- 🔮 **未来趋势预测**
  - 短期（1-3天）
  - 中期（1-2周）
  - 长期（1个月+）
- 💡 **关键转折点识别**

待分析内容：
{combined_content}""",

        'compare': f"""你是一位专业的对比分析师。请对以下{len(items)}条信息进行多维度对比分析。

## 对比维度
1. **观点对比**：不同信息源的观点异同
2. **立场分析**：各方立场和态度对比
3. **数据对比**：涉及的数据和事实对比
4. **时间对比**：不同时间点的变化对比

## 输出格式（markdown）
- 📊 **对比总览表**（表格形式）
- 🔍 **观点异同分析**
- ⚖️ **立场倾向对比**
- 📈 **数据差异说明**
- 💡 **对比结论**

待分析内容：
{combined_content}""",

        'event': f"""你是一位专业的事件分析师。请对以下{len(items)}条信息进行事件脉络分析。

## 分析任务
1. **事件还原**：还原事件的完整经过
2. **关键节点**：识别事件发展的关键节点
3. **因果分析**：分析事件的因果关系
4. **影响评估**：评估事件的影响范围和程度

## 输出格式（markdown）
- 📋 **事件概述**
- 🗓️ **事件时间线**（按时间顺序）
- 🎯 **关键节点**
- 🔗 **因果关系图描述**
- 👥 **相关方分析**
- 📊 **影响评估**
- 🔮 **后续发展预判**

待分析内容：
{combined_content}""",

        'policy': f"""你是一位资深的政策分析专家。请对以下{len(items)}条信息进行政策解读分析。

## 分析任务
1. **政策要点**：提取政策的核心内容和要点
2. **背景分析**：分析政策出台的背景和原因
3. **影响评估**：评估政策对各方的影响
4. **执行建议**：提出政策执行的建议

## 输出格式（markdown）
- 📜 **政策概述**
- 🎯 **核心要点**（列表形式）
- 📖 **背景解读**
- 👥 **影响分析**
  - 对政府的影响
  - 对企业的影响
  - 对公众的影响
- ⚙️ **执行要点**
- 💡 **应对建议**

待分析内容：
{combined_content}""",

        'hotspot': f"""你是一位专业的热点追踪分析师。请对以下{len(items)}条信息进行热点追踪分析。

## 分析任务
1. **热点识别**：识别当前的热点话题
2. **热度评估**：评估各热点的热度等级
3. **传播分析**：分析热点的传播特征
4. **持续预测**：预测热点的持续时间

## 输出格式（markdown）
- 🔥 **热点排行榜**（TOP5）
- 📊 **热度指数**（1-100分）
- 📈 **传播特征分析**
- ⏰ **热点生命周期预测**
- 🎯 **关注建议**

待分析内容：
{combined_content}"""
    }
    
    prompt = prompts.get(analysis_type, prompts['summary'])
    
    try:
        result = call_ai_api(engine, prompt, max_tokens=4000)
        
        # 保存分析历史记录
        type_names = {
            'summary': '智能摘要',
            'sentiment': '情感分析',
            'keywords': '关键词提取',
            'risk': '风险评估',
            'report': '综合分析报告',
            'trend': '趋势分析',
            'compare': '对比分析',
            'event': '事件脉络',
            'policy': '政策解读',
            'hotspot': '热点追踪'
        }
        title = f"{type_names.get(analysis_type, '分析')} - {len(items)}条数据"
        
        try:
            db.execute(
                '''INSERT INTO ai_analysis_history 
                   (title, analysis_type, data_ids, data_count, result, engine_id, engine_name, model_name, user_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (title, analysis_type, ','.join(map(str, data_ids)), len(items), result, 
                 engine['id'], engine['name'], engine['model_name'], session.get('user_id'))
            )
            db.commit()
        except:
            pass  # 保存失败不影响返回结果
        
        return jsonify({
            'code': 0,
            'msg': '分析完成',
            'data': {
                'type': analysis_type,
                'result': result,
                'engine': {
                    'name': engine['name'],
                    'model': engine['model_name']
                },
                'analyzed_count': len(items)
            }
        })
    except req.exceptions.Timeout:
        return jsonify({'code': 1, 'msg': 'AI分析超时，请稍后重试'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'分析失败: {str(e)}'})


@app.route('/api/ai/analyze/<int:data_id>', methods=['POST'])
@login_required
def api_ai_analyze_single(data_id):
    """单条数据AI分析接口"""
    import requests as req
    
    data = request.get_json() or {}
    analysis_type = data.get('type', 'report')
    engine_id = data.get('engine_id')
    
    # 获取AI引擎
    db = get_db()
    if engine_id:
        engine = db.execute('SELECT * FROM ai_engines WHERE id = ? AND status = 1', (engine_id,)).fetchone()
    else:
        engine = db.execute('SELECT * FROM ai_engines WHERE status = 1 ORDER BY id LIMIT 1').fetchone()
    
    if not engine:
        return jsonify({'code': 1, 'msg': '没有可用的AI引擎，请先在AI引擎管理中添加并启用引擎'})
    
    engine = dict(engine)
    
    # 获取数据
    item = db.execute('SELECT * FROM crawl_data WHERE id = ?', (data_id,)).fetchone()
    if not item:
        return jsonify({'code': 1, 'msg': '数据不存在'})
    
    item = dict(item)
    
    # 构建内容
    content = f"【标题】{item['title']}\n"
    if item.get('summary'):
        content += f"【摘要】{item['summary']}\n"
    if item.get('content'):
        content += f"【正文】{item['content']}\n"
    if item.get('source'):
        content += f"【来源】{item['source']}\n"
    if item.get('url'):
        content += f"【链接】{item['url']}\n"
    
    prompt = f"""你是一位专业的舆情分析师。请对以下信息进行全面的智能分析，生成一份专业的分析报告。

## 分析要求

### 📋 内容摘要
- 用2-3句话精准概括核心内容
- 提炼关键信息点

### 😊😐😟 情感分析
- 判断情感倾向（正面/中性/负面）
- 情感强度评分（1-5分）
- 分析情感倾向的原因

### 🏷️ 关键信息提取
- **关键词**：提取5-10个核心关键词
- **人物**：识别涉及的重要人物
- **机构**：识别涉及的政府部门、企业、组织
- **地点**：识别涉及的地理位置
- **时间**：识别涉及的时间节点

### ⚠️ 风险评估
- **风险等级**：🟢低危/🟡中危/🟠高危/🔴严重
- **风险评分**：1-100分
- **风险点说明**：具体的风险因素
- **传播风险**：可能的传播范围和影响

### 💡 处理建议
- **即时建议**：需要立即采取的措施
- **跟进建议**：后续需要关注的事项
- **预防建议**：避免类似问题的措施

## 输出格式
请使用markdown格式，结构清晰，适当使用emoji增强可读性。

待分析内容：
{content}"""
    
    try:
        result = call_ai_api(engine, prompt, max_tokens=3000)
        
        # 保存单条分析历史
        try:
            db.execute(
                '''INSERT INTO ai_analysis_history 
                   (title, analysis_type, data_ids, data_count, result, engine_id, engine_name, model_name, user_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (f"单条分析 - {item['title'][:30]}", 'single', str(data_id), 1, result, 
                 engine['id'], engine['name'], engine['model_name'], session.get('user_id'))
            )
            db.commit()
        except:
            pass
        
        return jsonify({
            'code': 0,
            'msg': '分析完成',
            'data': {
                'data_id': data_id,
                'title': item['title'],
                'result': result,
                'engine': {
                    'name': engine['name'],
                    'model': engine['model_name']
                }
            }
        })
    except req.exceptions.Timeout:
        return jsonify({'code': 1, 'msg': 'AI分析超时，请稍后重试'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'分析失败: {str(e)}'})


# ==================== AI分析历史记录接口 ====================
@app.route('/api/ai/history', methods=['GET'])
@login_required
def api_ai_history_list():
    """获取AI分析历史记录列表"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    analysis_type = request.args.get('type', '').strip()
    keyword = request.args.get('keyword', '').strip()
    offset = (page - 1) * limit
    
    conditions = ['1=1']
    params = []
    
    if analysis_type:
        conditions.append('analysis_type = ?')
        params.append(analysis_type)
    
    if keyword:
        conditions.append('(title LIKE ? OR result LIKE ?)')
        params.extend([f'%{keyword}%', f'%{keyword}%'])
    
    where_clause = ' AND '.join(conditions)
    
    data = db.execute(
        f'''SELECT id, title, analysis_type, data_count, engine_name, model_name, created_at
           FROM ai_analysis_history WHERE {where_clause}
           ORDER BY created_at DESC LIMIT ? OFFSET ?''',
        params + [limit, offset]
    ).fetchall()
    
    total = db.execute(
        f'SELECT COUNT(*) FROM ai_analysis_history WHERE {where_clause}',
        params
    ).fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(row) for row in data]
    })


@app.route('/api/ai/history/<int:id>', methods=['GET'])
@login_required
def api_ai_history_detail(id):
    """获取AI分析历史详情"""
    db = get_db()
    history = db.execute('SELECT * FROM ai_analysis_history WHERE id = ?', (id,)).fetchone()
    
    if not history:
        return jsonify({'code': 1, 'msg': '记录不存在'})
    
    return jsonify({'code': 0, 'data': dict(history)})


@app.route('/api/ai/history/<int:id>', methods=['DELETE'])
@login_required
def api_ai_history_delete(id):
    """删除AI分析历史记录"""
    db = get_db()
    db.execute('DELETE FROM ai_analysis_history WHERE id = ?', (id,))
    db.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


@app.route('/api/ai/analysis-types', methods=['GET'])
@login_required
def api_ai_analysis_types():
    """获取所有分析类型"""
    types = [
        {'value': 'summary', 'label': '智能摘要', 'icon': '📋', 'description': '提取核心要点，生成简洁摘要'},
        {'value': 'sentiment', 'label': '情感分析', 'icon': '😊', 'description': '分析情感倾向和舆情风险'},
        {'value': 'keywords', 'label': '关键词提取', 'icon': '🏷️', 'description': '提取关键词和命名实体'},
        {'value': 'risk', 'label': '风险评估', 'icon': '⚠️', 'description': '评估舆情风险等级'},
        {'value': 'report', 'label': '综合报告', 'icon': '📊', 'description': '生成完整的舆情分析报告'},
        {'value': 'trend', 'label': '趋势分析', 'icon': '📈', 'description': '分析发展趋势和热度变化'},
        {'value': 'compare', 'label': '对比分析', 'icon': '⚖️', 'description': '多维度对比分析'},
        {'value': 'event', 'label': '事件脉络', 'icon': '🗓️', 'description': '还原事件发展脉络'},
        {'value': 'policy', 'label': '政策解读', 'icon': '📜', 'description': '政策要点解读和影响分析'},
        {'value': 'hotspot', 'label': '热点追踪', 'icon': '🔥', 'description': '识别和追踪热点话题'}
    ]
    return jsonify({'code': 0, 'data': types})


@app.route('/api/ai/quick-analyze', methods=['POST'])
@login_required
def api_ai_quick_analyze():
    """快速AI分析 - 直接输入文本进行分析"""
    import requests as req
    
    data = request.get_json()
    text = data.get('text', '').strip()
    analysis_type = data.get('type', 'summary')
    engine_id = data.get('engine_id')
    
    if not text:
        return jsonify({'code': 1, 'msg': '请输入要分析的文本'})
    
    if len(text) > 10000:
        return jsonify({'code': 1, 'msg': '文本长度不能超过10000字'})
    
    # 获取AI引擎
    db = get_db()
    if engine_id:
        engine = db.execute('SELECT * FROM ai_engines WHERE id = ? AND status = 1', (engine_id,)).fetchone()
    else:
        engine = db.execute('SELECT * FROM ai_engines WHERE status = 1 ORDER BY id LIMIT 1').fetchone()
    
    if not engine:
        return jsonify({'code': 1, 'msg': '没有可用的AI引擎'})
    
    engine = dict(engine)
    
    # 构建提示词
    prompts = {
        'summary': f"""请对以下文本进行智能摘要分析：

## 要求
1. 提取核心要点
2. 归纳主要内容
3. 使用markdown格式输出

待分析文本：
{text}""",
        'sentiment': f"""请对以下文本进行情感分析：

## 要求
1. 判断情感倾向（正面/中性/负面）
2. 评估情感强度（1-5分）
3. 识别情感关键词
4. 使用markdown格式输出

待分析文本：
{text}""",
        'keywords': f"""请对以下文本进行关键词提取：

## 要求
1. 提取核心关键词（10-15个）
2. 识别人物、机构、地点等实体
3. 按重要性排序
4. 使用markdown格式输出

待分析文本：
{text}""",
        'risk': f"""请对以下文本进行风险评估：

## 要求
1. 识别潜在风险点
2. 评估风险等级（低危/中危/高危/严重）
3. 提出应对建议
4. 使用markdown格式输出

待分析文本：
{text}"""
    }
    
    prompt = prompts.get(analysis_type, prompts['summary'])
    
    try:
        result = call_ai_api(engine, prompt, max_tokens=2000)
        return jsonify({
            'code': 0,
            'msg': '分析完成',
            'data': {
                'type': analysis_type,
                'result': result,
                'engine': {
                    'name': engine['name'],
                    'model': engine['model_name']
                }
            }
        })
    except req.exceptions.Timeout:
        return jsonify({'code': 1, 'msg': 'AI分析超时'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'分析失败: {str(e)}'})


# ==================== 采集规则管理模块 ====================
@app.route('/crawl-rules')
@login_required
def crawl_rules_page():
    """采集规则管理页面"""
    return render_template('crawl_rules.html')


@app.route('/api/crawl-rules', methods=['GET'])
@login_required
def api_crawl_rules_list():
    """获取采集规则列表"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '').strip()
    offset = (page - 1) * limit
    
    conditions = ['1=1']
    params = []
    
    if keyword:
        conditions.append('(name LIKE ? OR url_pattern LIKE ? OR description LIKE ?)')
        params.extend([f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'])
    
    where_clause = ' AND '.join(conditions)
    
    data = db.execute(
        f'''SELECT * FROM crawl_rules WHERE {where_clause}
           ORDER BY created_at DESC LIMIT ? OFFSET ?''',
        params + [limit, offset]
    ).fetchall()
    
    total = db.execute(
        f'SELECT COUNT(*) FROM crawl_rules WHERE {where_clause}',
        params
    ).fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(row) for row in data]
    })


@app.route('/api/crawl-rules', methods=['POST'])
@login_required
def api_crawl_rules_create():
    """创建采集规则"""
    data = request.get_json()
    
    name = data.get('name', '').strip()
    url_pattern = data.get('url_pattern', '').strip()
    title_xpath = data.get('title_xpath', '').strip()
    content_xpath = data.get('content_xpath', '').strip()
    request_headers = data.get('request_headers', '').strip()
    description = data.get('description', '').strip()
    
    if not name:
        return jsonify({'code': 1, 'msg': '请输入规则名称'})
    if not url_pattern:
        return jsonify({'code': 1, 'msg': '请输入URL匹配规则'})
    
    try:
        db = get_db()
        db.execute(
            '''INSERT INTO crawl_rules (name, url_pattern, title_xpath, content_xpath, 
               request_headers, description, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (name, url_pattern, title_xpath, content_xpath, request_headers, 
             description, session.get('user_id'))
        )
        db.commit()
        return jsonify({'code': 0, 'msg': '创建成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'创建失败: {str(e)}'})


@app.route('/api/crawl-rules/<int:id>', methods=['GET'])
@login_required
def api_crawl_rules_detail(id):
    """获取采集规则详情"""
    db = get_db()
    rule = db.execute('SELECT * FROM crawl_rules WHERE id = ?', (id,)).fetchone()
    
    if not rule:
        return jsonify({'code': 1, 'msg': '规则不存在'})
    
    return jsonify({'code': 0, 'data': dict(rule)})


@app.route('/api/crawl-rules/<int:id>', methods=['PUT'])
@login_required
def api_crawl_rules_update(id):
    """更新采集规则"""
    data = request.get_json()
    
    name = data.get('name', '').strip()
    url_pattern = data.get('url_pattern', '').strip()
    title_xpath = data.get('title_xpath', '').strip()
    content_xpath = data.get('content_xpath', '').strip()
    request_headers = data.get('request_headers', '').strip()
    description = data.get('description', '').strip()
    status = data.get('status', 1)
    
    if not name:
        return jsonify({'code': 1, 'msg': '请输入规则名称'})
    if not url_pattern:
        return jsonify({'code': 1, 'msg': '请输入URL匹配规则'})
    
    try:
        db = get_db()
        db.execute(
            '''UPDATE crawl_rules SET name = ?, url_pattern = ?, title_xpath = ?, 
               content_xpath = ?, request_headers = ?, description = ?, status = ?,
               updated_at = CURRENT_TIMESTAMP WHERE id = ?''',
            (name, url_pattern, title_xpath, content_xpath, request_headers, 
             description, status, id)
        )
        db.commit()
        return jsonify({'code': 0, 'msg': '更新成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'更新失败: {str(e)}'})


@app.route('/api/crawl-rules/<int:id>', methods=['DELETE'])
@login_required
def api_crawl_rules_delete(id):
    """删除采集规则"""
    try:
        db = get_db()
        db.execute('DELETE FROM crawl_rules WHERE id = ?', (id,))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


@app.route('/api/crawl-rules/<int:id>/toggle', methods=['POST'])
@login_required
def api_crawl_rules_toggle(id):
    """切换采集规则状态"""
    try:
        db = get_db()
        rule = db.execute('SELECT status FROM crawl_rules WHERE id = ?', (id,)).fetchone()
        if not rule:
            return jsonify({'code': 1, 'msg': '规则不存在'})
        
        new_status = 0 if rule['status'] == 1 else 1
        db.execute('UPDATE crawl_rules SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
                   (new_status, id))
        db.commit()
        return jsonify({'code': 0, 'msg': '状态已更新', 'data': {'status': new_status}})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'操作失败: {str(e)}'})


@app.route('/api/crawl-rules/all', methods=['GET'])
@login_required
def api_crawl_rules_all():
    """获取所有启用的采集规则（用于深度采集匹配）"""
    db = get_db()
    rules = db.execute(
        'SELECT id, name, url_pattern, title_xpath, content_xpath, request_headers FROM crawl_rules WHERE status = 1'
    ).fetchall()
    return jsonify({'code': 0, 'data': [dict(r) for r in rules]})


# ==================== AI分析历史页面 ====================
@app.route('/ai-history')
@login_required
def ai_history_page():
    """AI分析历史页面"""
    return render_template('ai_history.html')


# ==================== AI引擎管理 ====================
@app.route('/ai-engines')
@login_required
def ai_engines_page():
    """AI引擎管理页面"""
    return render_template('ai_engines.html')


@app.route('/api/ai-engines', methods=['GET'])
@login_required
def api_ai_engines_list():
    """获取AI引擎列表"""
    db = get_db()
    engines = db.execute(
        'SELECT * FROM ai_engines ORDER BY created_at DESC'
    ).fetchall()
    return jsonify({
        'code': 0,
        'msg': '',
        'count': len(engines),
        'data': [dict(e) for e in engines]
    })


@app.route('/api/ai-engines', methods=['POST'])
@login_required
def api_ai_engines_add():
    """添加AI引擎"""
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        provider = data.get('provider', '').strip()
        api_url = data.get('api_url', '').strip()
        api_key = data.get('api_key', '').strip()
        model_name = data.get('model_name', '').strip()
        description = data.get('description', '').strip()
        icon_color = data.get('icon_color', '#1890ff')
        
        if not all([name, provider, api_url, api_key, model_name]):
            return jsonify({'code': 1, 'msg': '请填写完整的引擎信息'})
        
        db = get_db()
        db.execute(
            '''INSERT INTO ai_engines (name, provider, api_url, api_key, model_name, description, icon_color, user_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
            (name, provider, api_url, api_key, model_name, description, icon_color, session.get('user_id'))
        )
        db.commit()
        return jsonify({'code': 0, 'msg': '添加成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'添加失败: {str(e)}'})


@app.route('/api/ai-engines/<int:id>', methods=['GET'])
@login_required
def api_ai_engines_get(id):
    """获取单个AI引擎详情"""
    db = get_db()
    engine = db.execute('SELECT * FROM ai_engines WHERE id = ?', (id,)).fetchone()
    if not engine:
        return jsonify({'code': 1, 'msg': '引擎不存在'})
    return jsonify({'code': 0, 'data': dict(engine)})


@app.route('/api/ai-engines/<int:id>', methods=['PUT'])
@login_required
def api_ai_engines_update(id):
    """更新AI引擎"""
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        provider = data.get('provider', '').strip()
        api_url = data.get('api_url', '').strip()
        api_key = data.get('api_key', '').strip()
        model_name = data.get('model_name', '').strip()
        description = data.get('description', '').strip()
        icon_color = data.get('icon_color', '#1890ff')
        
        if not all([name, provider, api_url, api_key, model_name]):
            return jsonify({'code': 1, 'msg': '请填写完整的引擎信息'})
        
        db = get_db()
        db.execute(
            '''UPDATE ai_engines SET name=?, provider=?, api_url=?, api_key=?, model_name=?, 
               description=?, icon_color=?, updated_at=CURRENT_TIMESTAMP WHERE id=?''',
            (name, provider, api_url, api_key, model_name, description, icon_color, id)
        )
        db.commit()
        return jsonify({'code': 0, 'msg': '更新成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'更新失败: {str(e)}'})


@app.route('/api/ai-engines/<int:id>', methods=['DELETE'])
@login_required
def api_ai_engines_delete(id):
    """删除AI引擎"""
    try:
        db = get_db()
        db.execute('DELETE FROM ai_engines WHERE id = ?', (id,))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


@app.route('/api/ai-engines/<int:id>/toggle', methods=['POST'])
@login_required
def api_ai_engines_toggle(id):
    """切换AI引擎状态"""
    try:
        db = get_db()
        engine = db.execute('SELECT status FROM ai_engines WHERE id = ?', (id,)).fetchone()
        if not engine:
            return jsonify({'code': 1, 'msg': '引擎不存在'})
        
        new_status = 0 if engine['status'] == 1 else 1
        db.execute('UPDATE ai_engines SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
                   (new_status, id))
        db.commit()
        return jsonify({'code': 0, 'msg': '状态已更新', 'data': {'status': new_status}})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'操作失败: {str(e)}'})


@app.route('/api/ai-engines/<int:id>/test', methods=['POST'])
@login_required
def api_ai_engines_test(id):
    """测试AI引擎连接"""
    try:
        import requests as req
        
        db = get_db()
        engine = db.execute('SELECT * FROM ai_engines WHERE id = ?', (id,)).fetchone()
        if not engine:
            return jsonify({'code': 1, 'msg': '引擎不存在'})
        
        # 构建测试请求
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {engine["api_key"]}'
        }
        
        payload = {
            'model': engine['model_name'],
            'messages': [{'role': 'user', 'content': '你好，请简单回复"连接成功"'}],
            'max_tokens': 50
        }
        
        response = req.post(
            engine['api_url'],
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            return jsonify({'code': 0, 'msg': '连接测试成功！AI引擎响应正常'})
        else:
            return jsonify({'code': 1, 'msg': f'连接失败: HTTP {response.status_code} - {response.text[:200]}'})
    except req.exceptions.Timeout:
        return jsonify({'code': 1, 'msg': '连接超时，请检查API地址是否正确'})
    except req.exceptions.ConnectionError:
        return jsonify({'code': 1, 'msg': '无法连接到服务器，请检查API地址'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'测试失败: {str(e)}'})


if __name__ == '__main__':
    # 初始化数据库
    if not os.path.exists(DATABASE):
        init_db()
    else:
        # 确保新表存在
        with app.app_context():
            db = get_db()
            db.execute('''
                CREATE TABLE IF NOT EXISTS crawl_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    url_pattern TEXT NOT NULL,
                    title_xpath TEXT,
                    content_xpath TEXT,
                    request_headers TEXT,
                    status INTEGER DEFAULT 1,
                    description TEXT,
                    user_id INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            ''')
            db.execute('''
                CREATE TABLE IF NOT EXISTS ai_engines (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    api_url TEXT NOT NULL,
                    api_key TEXT NOT NULL,
                    model_name TEXT NOT NULL,
                    status INTEGER DEFAULT 1,
                    description TEXT,
                    icon_color TEXT DEFAULT '#1890ff',
                    user_id INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users (id)
                )
            ''')
            db.commit()
    app.run(debug=True, host='0.0.0.0', port=5000)
