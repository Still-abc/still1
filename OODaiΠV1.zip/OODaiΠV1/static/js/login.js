(function(){
  const nicknameEl = document.getElementById('nickname');
  const passwordEl = document.getElementById('password');
  const serverSelect = document.getElementById('serverSelect');
  const loginBtn = document.getElementById('loginBtn');
  const agreeEl = document.getElementById('agree');

  // Load servers
  fetch('/config').then(r=>r.json()).then(cfg=>{
    const servers = cfg.servers || [];
    servers.forEach(s=>{
      // Normalize localhost to 127.0.0.1 to match server binding on Windows
      const normalized = s.replace('localhost', '127.0.0.1');
      const opt = document.createElement('option');
      opt.value = normalized; opt.textContent = normalized; serverSelect.appendChild(opt);
    });
    // Fallback if empty
    if(serverSelect.options.length === 0){
      const opt = document.createElement('option');
      opt.value = 'ws://127.0.0.1:8088/ws'; opt.textContent = 'ws://127.0.0.1:8088/ws'; serverSelect.appendChild(opt);
    }
  }).catch(()=>{
    const opt = document.createElement('option');
    opt.value = 'ws://127.0.0.1:8088/ws'; opt.textContent = 'ws://127.0.0.1:8088/ws'; serverSelect.appendChild(opt);
  });

  function showMsg(msg){ alert(msg); }

  loginBtn.addEventListener('click', function(){
    const nickname = (nicknameEl.value||'').trim();
    const password = (passwordEl.value||'').trim();
    const server = serverSelect.value;
    if(!nickname){ return showMsg('请输入昵称'); }
    if(password !== '123456'){ return showMsg('密码错误，固定密码为 123456'); }
    if(!agreeEl.checked){ return showMsg('请勾选同意服务协议与隐私指引'); }

    fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nickname, password })
    }).then(r=>r.json()).then(res=>{
      if(res.ok){
        const url = '/chat?nick=' + encodeURIComponent(nickname) + '&server=' + encodeURIComponent(server);
        window.location.href = url;
      }else{
        showMsg(res.msg || '登录失败');
      }
    }).catch(()=>showMsg('网络异常'));
  });
})();