from flask import Flask, render_template, g, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import sqlite3
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'gov-info-check-system-secret-key-2024'
# 支持代理环境下的Session（IDE预览模式）
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True

DATABASE = 'database.db'


# ==================== 数据库操作 ====================
def get_db():
    """获取数据库连接"""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db


@app.teardown_appcontext
def close_connection(exception):
    """关闭数据库连接"""
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    """初始化数据库"""
    with app.app_context():
        db = get_db()
        
        # 角色表
        db.execute('''
            CREATE TABLE IF NOT EXISTS roles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 用户表
        db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL,
                role_id INTEGER DEFAULT 2,
                status INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (role_id) REFERENCES roles (id)
            )
        ''')
        
        # 系统设置表
        db.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL UNIQUE,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 抓取日志表
        db.execute('''
            CREATE TABLE IF NOT EXISTS crawl_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                keyword TEXT NOT NULL,
                result_count INTEGER DEFAULT 0,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # 数据仓表
        db.execute('''
            CREATE TABLE IF NOT EXISTS data_warehouses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # 采集数据表
        db.execute('''
            CREATE TABLE IF NOT EXISTS crawl_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                summary TEXT,
                cover TEXT,
                url TEXT NOT NULL,
                source TEXT,
                content TEXT,
                deep_status INTEGER DEFAULT 0,
                keyword TEXT,
                warehouse_id INTEGER,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (warehouse_id) REFERENCES data_warehouses (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        db.commit()
        
        # 初始化默认角色
        try:
            db.execute("INSERT INTO roles (id, name, description) VALUES (1, 'admin', '管理员')")
            db.execute("INSERT INTO roles (id, name, description) VALUES (2, 'user', '普通用户')")
            db.commit()
        except sqlite3.IntegrityError:
            pass
        
        # 初始化默认管理员账户 admin/admin123
        try:
            admin_password = generate_password_hash('admin123')
            db.execute("INSERT INTO users (username, password, role_id) VALUES (?, ?, 1)", 
                      ('admin', admin_password))
            db.commit()
        except sqlite3.IntegrityError:
            pass
        
        # 初始化默认系统设置
        try:
            db.execute("INSERT INTO settings (key, value) VALUES ('app_name', '政企智能舆情分析报告生成智能体应用系统')")
            db.execute("INSERT INTO settings (key, value) VALUES ('logo_url', '')")
            db.commit()
        except sqlite3.IntegrityError:
            pass


def get_settings():
    """获取系统设置"""
    db = get_db()
    settings = db.execute('SELECT key, value FROM settings').fetchall()
    return {s['key']: s['value'] for s in settings}


# ==================== 权限装饰器 ====================
def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        if session.get('role_id') != 1:
            flash('权限不足，需要管理员权限', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


# ==================== 上下文处理器 ====================
@app.context_processor
def inject_settings():
    """注入系统设置到模板"""
    try:
        settings = get_settings()
        return {'app_settings': settings}
    except:
        return {'app_settings': {'app_name': '政企智能舆情分析报告生成智能体应用系统', 'logo_url': ''}}


# ==================== 路由 ====================
@app.route('/')
def index():
    """首页 - 重定向到登录或仪表盘"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        remember = request.form.get('remember', False)
        
        if not username or not password:
            return jsonify({'code': 1, 'msg': '请输入用户名和密码'})
        
        db = get_db()
        user = db.execute(
            'SELECT u.*, r.name as role_name FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE u.username = ?',
            (username,)
        ).fetchone()
        
        if user is None:
            return jsonify({'code': 1, 'msg': '用户名不存在'})
        
        if not check_password_hash(user['password'], password):
            return jsonify({'code': 1, 'msg': '密码错误'})
        
        if user['status'] != 1:
            return jsonify({'code': 1, 'msg': '账户已被禁用'})
        
        # 设置session
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['role_id'] = user['role_id']
        session['role_name'] = user['role_name']
        
        if remember:
            session.permanent = True
        
        return jsonify({'code': 0, 'msg': '登录成功', 'url': url_for('dashboard')})
    
    return render_template('login.html')


@app.route('/logout')
def logout():
    """退出登录"""
    session.clear()
    return redirect(url_for('login'))


@app.route('/dashboard')
@login_required
def dashboard():
    """仪表盘/首页"""
    return render_template('dashboard.html')


# ==================== 用户管理 ====================
@app.route('/admin/users')
@admin_required
def admin_users():
    """用户管理页面"""
    return render_template('admin/users.html')


@app.route('/api/users', methods=['GET'])
@admin_required
def api_users_list():
    """获取用户列表"""
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    keyword = request.args.get('keyword', '')
    
    db = get_db()
    offset = (page - 1) * limit
    
    if keyword:
        users = db.execute(
            '''SELECT u.id, u.username, u.role_id, u.status, u.created_at, r.name as role_name 
               FROM users u LEFT JOIN roles r ON u.role_id = r.id 
               WHERE u.username LIKE ? ORDER BY u.id DESC LIMIT ? OFFSET ?''',
            (f'%{keyword}%', limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM users WHERE username LIKE ?', (f'%{keyword}%',)).fetchone()[0]
    else:
        users = db.execute(
            '''SELECT u.id, u.username, u.role_id, u.status, u.created_at, r.name as role_name 
               FROM users u LEFT JOIN roles r ON u.role_id = r.id 
               ORDER BY u.id DESC LIMIT ? OFFSET ?''',
            (limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    
    return jsonify({
        'code': 0,
        'msg': '',
        'count': total,
        'data': [dict(u) for u in users]
    })


@app.route('/api/users', methods=['POST'])
@admin_required
def api_users_add():
    """添加用户"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    role_id = data.get('role_id', 2)
    
    if not username or not password:
        return jsonify({'code': 1, 'msg': '用户名和密码不能为空'})
    
    if len(password) < 6:
        return jsonify({'code': 1, 'msg': '密码长度至少6位'})
    
    db = get_db()
    try:
        db.execute(
            'INSERT INTO users (username, password, role_id) VALUES (?, ?, ?)',
            (username, generate_password_hash(password), role_id)
        )
        db.commit()
        return jsonify({'code': 0, 'msg': '添加成功'})
    except sqlite3.IntegrityError:
        return jsonify({'code': 1, 'msg': '用户名已存在'})


@app.route('/api/users/<int:user_id>', methods=['PUT'])
@admin_required
def api_users_update(user_id):
    """更新用户"""
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    role_id = data.get('role_id')
    status = data.get('status')
    
    db = get_db()
    
    if username:
        try:
            db.execute('UPDATE users SET username = ? WHERE id = ?', (username, user_id))
        except sqlite3.IntegrityError:
            return jsonify({'code': 1, 'msg': '用户名已存在'})
    
    if password:
        if len(password) < 6:
            return jsonify({'code': 1, 'msg': '密码长度至少6位'})
        db.execute('UPDATE users SET password = ? WHERE id = ?', (generate_password_hash(password), user_id))
    
    if role_id is not None:
        db.execute('UPDATE users SET role_id = ? WHERE id = ?', (role_id, user_id))
    
    if status is not None:
        db.execute('UPDATE users SET status = ? WHERE id = ?', (status, user_id))
    
    db.commit()
    return jsonify({'code': 0, 'msg': '更新成功'})


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
@admin_required
def api_users_delete(user_id):
    """删除用户"""
    if user_id == session.get('user_id'):
        return jsonify({'code': 1, 'msg': '不能删除当前登录用户'})
    
    db = get_db()
    db.execute('DELETE FROM users WHERE id = ?', (user_id,))
    db.commit()
    return jsonify({'code': 0, 'msg': '删除成功'})


# ==================== 角色管理 ====================
@app.route('/admin/roles')
@admin_required
def admin_roles():
    """角色管理页面"""
    return render_template('admin/roles.html')


@app.route('/api/roles', methods=['GET'])
@admin_required
def api_roles_list():
    """获取角色列表"""
    db = get_db()
    roles = db.execute('SELECT * FROM roles ORDER BY id').fetchall()
    return jsonify({
        'code': 0,
        'msg': '',
        'count': len(roles),
        'data': [dict(r) for r in roles]
    })


# ==================== 系统设置 ====================
@app.route('/admin/settings')
@admin_required
def admin_settings():
    """系统设置页面"""
    return render_template('admin/settings.html')


@app.route('/api/settings', methods=['GET'])
@admin_required
def api_settings_get():
    """获取系统设置"""
    settings = get_settings()
    return jsonify({'code': 0, 'data': settings})


@app.route('/api/settings', methods=['POST'])
@admin_required
def api_settings_update():
    """更新系统设置"""
    data = request.get_json()
    db = get_db()
    
    for key, value in data.items():
        db.execute(
            'INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)',
            (key, value)
        )
    
    db.commit()
    return jsonify({'code': 0, 'msg': '保存成功'})


# ==================== 数据抓取模块 ====================
@app.route('/crawler')
@login_required
def crawler_page():
    """数据抓取页面"""
    return render_template('crawler.html')


@app.route('/api/crawler/search', methods=['POST'])
@login_required
def api_crawler_search():
    """执行数据抓取"""
    from crawler import crawl_baidu
    
    data = request.get_json()
    keyword = data.get('keyword', '').strip()
    count = data.get('count', 10)  # 获取采集条数
    source_type = data.get('source_type', '')  # 来源类型筛选
    
    if not keyword:
        return jsonify({'code': 1, 'msg': '请输入搜索关键字'})
    
    # 限制采集条数范围
    if count < 1:
        count = 10
    elif count > 100:
        count = 100
    
    try:
        results = crawl_baidu(keyword, count=count, source_type=source_type)
        
        # 保存抓取记录到数据库
        db = get_db()
        db.execute(
            'INSERT INTO crawl_logs (keyword, result_count, user_id) VALUES (?, ?, ?)',
            (keyword, len(results), session.get('user_id'))
        )
        db.commit()
        
        return jsonify({
            'code': 0,
            'msg': f'成功抓取 {len(results)} 条数据',
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'抓取失败: {str(e)}'})


@app.route('/api/crawler/logs', methods=['GET'])
@login_required
def api_crawler_logs():
    """获取抓取历史记录"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    offset = (page - 1) * limit
    
    logs = db.execute(
        '''SELECT cl.*, u.username FROM crawl_logs cl 
           LEFT JOIN users u ON cl.user_id = u.id 
           ORDER BY cl.created_at DESC LIMIT ? OFFSET ?''',
        (limit, offset)
    ).fetchall()
    
    total = db.execute('SELECT COUNT(*) FROM crawl_logs').fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(log) for log in logs]
    })


@app.route('/api/warehouse/list', methods=['GET'])
@login_required
def api_warehouse_list():
    """获取数据仓列表"""
    db = get_db()
    warehouses = db.execute(
        '''SELECT dw.*, COUNT(cd.id) as data_count 
           FROM data_warehouses dw 
           LEFT JOIN crawl_data cd ON dw.id = cd.warehouse_id
           WHERE dw.user_id = ?
           GROUP BY dw.id
           ORDER BY dw.created_at DESC''',
        (session.get('user_id'),)
    ).fetchall()
    
    return jsonify({
        'code': 0,
        'data': [dict(w) for w in warehouses]
    })


@app.route('/api/warehouse/create', methods=['POST'])
@login_required
def api_warehouse_create():
    """创建数据仓"""
    data = request.get_json()
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()
    
    if not name:
        return jsonify({'code': 1, 'msg': '请输入数据仓名称'})
    
    try:
        db = get_db()
        # 检查是否已存在同名数据仓
        existing = db.execute(
            'SELECT id FROM data_warehouses WHERE name = ? AND user_id = ?',
            (name, session.get('user_id'))
        ).fetchone()
        
        if existing:
            return jsonify({'code': 1, 'msg': '数据仓名称已存在'})
        
        db.execute(
            'INSERT INTO data_warehouses (name, description, user_id) VALUES (?, ?, ?)',
            (name, description, session.get('user_id'))
        )
        db.commit()
        
        return jsonify({'code': 0, 'msg': '数据仓创建成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'创建失败: {str(e)}'})


@app.route('/api/warehouse/<int:id>', methods=['DELETE'])
@login_required
def api_warehouse_delete(id):
    """删除数据仓"""
    try:
        db = get_db()
        # 先删除数据仓中的数据
        db.execute('DELETE FROM crawl_data WHERE warehouse_id = ?', (id,))
        # 再删除数据仓
        db.execute('DELETE FROM data_warehouses WHERE id = ? AND user_id = ?', 
                   (id, session.get('user_id')))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


@app.route('/api/crawler/deep', methods=['POST'])
@login_required
def api_crawler_deep():
    """深度采集URL内容"""
    from crawler import deep_crawl_batch
    
    data = request.get_json()
    urls = data.get('urls', [])
    
    if not urls:
        return jsonify({'code': 1, 'msg': '请提供要采集的URL'})
    
    try:
        results = deep_crawl_batch(urls)
        return jsonify({
            'code': 0,
            'msg': f'成功深度采集 {len(results)} 条数据',
            'data': results
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'深度采集失败: {str(e)}'})


@app.route('/api/crawler/save', methods=['POST'])
@login_required
def api_crawler_save():
    """保存采集数据到数据仓"""
    data = request.get_json()
    keyword = data.get('keyword', '')
    items = data.get('items', [])
    warehouse_id = data.get('warehouse_id')  # 数据仓ID
    
    if not items:
        return jsonify({'code': 1, 'msg': '请选择要存储的数据'})
    
    if not warehouse_id:
        return jsonify({'code': 1, 'msg': '请选择数据仓'})
    
    try:
        db = get_db()
        
        # 验证数据仓是否存在且属于当前用户
        warehouse = db.execute(
            'SELECT id FROM data_warehouses WHERE id = ? AND user_id = ?',
            (warehouse_id, session.get('user_id'))
        ).fetchone()
        
        if not warehouse:
            return jsonify({'code': 1, 'msg': '数据仓不存在'})
        
        saved_count = 0
        
        for item in items:
            # 优先使用真实URL（深度采集后获取的）
            real_url = item.get('real_url') or item.get('url', '')
            
            # 检查是否已存在于该数据仓（根据URL和warehouse_id判断）
            existing = db.execute(
                'SELECT id FROM crawl_data WHERE url = ? AND warehouse_id = ?',
                (real_url, warehouse_id)
            ).fetchone()
            
            if not existing:
                db.execute(
                    '''INSERT INTO crawl_data 
                       (title, summary, cover, url, source, content, deep_status, keyword, warehouse_id, user_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                    (
                        item.get('title', ''),
                        item.get('summary', ''),
                        item.get('cover', ''),
                        real_url,  # 使用真实URL
                        item.get('source', ''),
                        item.get('content', ''),  # 保存详细内容
                        1 if item.get('_deepStatus') == 1 else 0,
                        keyword,
                        warehouse_id,
                        session.get('user_id')
                    )
                )
                saved_count += 1
        
        db.commit()
        
        return jsonify({
            'code': 0,
            'msg': f'成功存储 {saved_count} 条数据' + (f'，{len(items) - saved_count} 条已存在' if saved_count < len(items) else '')
        })
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'存储失败: {str(e)}'})


@app.route('/api/crawler/data', methods=['GET'])
@login_required
def api_crawler_data():
    """获取已存储的采集数据"""
    db = get_db()
    page = request.args.get('page', 1, type=int)
    limit = request.args.get('limit', 10, type=int)
    warehouse_id = request.args.get('warehouse_id', type=int)
    offset = (page - 1) * limit
    
    if warehouse_id:
        data = db.execute(
            '''SELECT cd.*, dw.name as warehouse_name FROM crawl_data cd
               LEFT JOIN data_warehouses dw ON cd.warehouse_id = dw.id
               WHERE cd.warehouse_id = ?
               ORDER BY cd.created_at DESC LIMIT ? OFFSET ?''',
            (warehouse_id, limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM crawl_data WHERE warehouse_id = ?', 
                          (warehouse_id,)).fetchone()[0]
    else:
        data = db.execute(
            '''SELECT cd.*, dw.name as warehouse_name FROM crawl_data cd
               LEFT JOIN data_warehouses dw ON cd.warehouse_id = dw.id
               WHERE cd.user_id = ?
               ORDER BY cd.created_at DESC LIMIT ? OFFSET ?''',
            (session.get('user_id'), limit, offset)
        ).fetchall()
        total = db.execute('SELECT COUNT(*) FROM crawl_data WHERE user_id = ?',
                          (session.get('user_id'),)).fetchone()[0]
    
    return jsonify({
        'code': 0,
        'count': total,
        'data': [dict(row) for row in data]
    })


@app.route('/api/crawler/data/<int:id>', methods=['DELETE'])
@login_required
def api_crawler_data_delete(id):
    """删除采集数据"""
    try:
        db = get_db()
        db.execute('DELETE FROM crawl_data WHERE id = ?', (id,))
        db.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})
    except Exception as e:
        return jsonify({'code': 1, 'msg': f'删除失败: {str(e)}'})


if __name__ == '__main__':
    # 初始化数据库
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
