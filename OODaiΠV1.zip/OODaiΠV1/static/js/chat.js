(function(){
  const meNickEl = document.getElementById('meNick');
  const messagesEl = document.getElementById('messages');
  const msgInputEl = document.getElementById('msgInput');
  const sendBtn = document.getElementById('sendBtn');
  const emojiBtn = document.getElementById('emojiBtn');
  const emojiPanel = document.getElementById('emojiPanel');
  const exitBtn = document.getElementById('exitBtn');
  const historyBtn = document.getElementById('historyBtn');

  const NICK = window.NICK || '匿名';
  let SERVER = (window.SERVER || '').replace('localhost', '127.0.0.1');

  meNickEl.textContent = NICK;

  // Build emoji panel with common emojis
  const EMOJIS = ['😀','😃','😄','😁','😆','🥹','😊','😍','😘','😜','🤩','🤔','🙃','😉','😎','😭','😡','👍','👎','👏','🙏','💪','🎉','💡','🔥','🌟','⚡','🍉','🍔','🍻','☕'];
  EMOJIS.forEach(e=>{
    const b=document.createElement('button'); b.textContent=e; b.addEventListener('click',()=>{
      msgInputEl.value += e;
      emojiPanel.classList.add('hidden');
      msgInputEl.focus();
    }); emojiPanel.appendChild(b);
  });
  emojiBtn.addEventListener('click',()=>{
    emojiPanel.classList.toggle('hidden');
  });

  historyBtn.addEventListener('click',()=>{
    alert('历史记录功能正在建设中');
  });

  exitBtn.addEventListener('click',()=>{
    window.location.href = '/login';
  });

  // Message rendering
  function createMsgBubble({type, nick, text, url, width, height}){
    const item = document.createElement('div');
    item.classList.add('msg');
    const me = nick === NICK && type !== 'system' && type !== 'bot' && type !== 'bot_stream_delta' && type !== 'bot_stream_start';
    item.classList.add(me ? 'me' : (type==='system'?'system':((type==='bot'||type==='bot_stream_delta'||type==='bot_stream_start')?'bot':'other')));
    const bubble = document.createElement('div');
    bubble.classList.add('bubble');
    const meta = document.createElement('div');
    meta.classList.add('meta');
    meta.textContent = (type==='system'?'系统':nick);
    const content = document.createElement('div');
    content.textContent = text || '';
    bubble.appendChild(meta);
    bubble.appendChild(content);

    // Music message: render audio player
    if(type === 'music' && url){
      const audio = document.createElement('audio');
      audio.controls = true;
      audio.src = url;
      audio.preload = 'none';
      audio.style.marginTop = '6px';
      bubble.appendChild(audio);
    }

    // Movie message: render iframe with specified size
    if(type === 'movie' && url){
      const frame = document.createElement('iframe');
      frame.src = url;
      frame.width = String(width || 1000);
      frame.height = String(height || 1000);
      frame.setAttribute('frameborder', '0');
      frame.style.display = 'block';
      frame.style.marginTop = '6px';
      bubble.appendChild(frame);
    }

    item.appendChild(bubble);
    messagesEl.appendChild(item);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return {item, bubble, meta, content};
  }

  function addMessage(m){
    return createMsgBubble(m);
  }

  // For streaming messages, keep a mapping from msg_id -> content node
  const streamMap = new Map();

  let ws;

  async function resolveServer(){
    if(SERVER && SERVER.startsWith('ws')) return SERVER;
    try{
      const cfg = await fetch('/config').then(r=>r.json());
      const servers = cfg.servers || [];
      // Prefer explicit servers; fallback to cfg.port
      SERVER = (servers[0] || (`ws://127.0.0.1:${(cfg.port||8088)}/ws`)).replace('localhost', '127.0.0.1');
    }catch(err){
      SERVER = 'ws://127.0.0.1:8088/ws';
    }
    return SERVER;
  }

  async function connect(){
    await resolveServer();
    try {
      const url = SERVER + (SERVER.includes('?')?'&':'?') + 'nick=' + encodeURIComponent(NICK);
      ws = new WebSocket(url);
    } catch(err){
      alert('WebSocket 连接失败');
      return;
    }
    ws.onopen = function(){
      addMessage({type:'system', nick:'系统', text:'已连接到服务器'});
    };
    ws.onmessage = function(ev){
      let data;
      try{ data = JSON.parse(ev.data); }catch{ data = {type:'chat', nick:'未知', text:String(ev.data)}; }
      const type = data.type;
      if(type === 'bot_stream_start'){
        const {content} = createMsgBubble({type:'bot_stream_start', nick:data.nick||'成小理', text:''});
        streamMap.set(data.msg_id, content);
      }else if(type === 'bot_stream_delta'){
        const content = streamMap.get(data.msg_id);
        if(content){ content.textContent += (data.text || ''); messagesEl.scrollTop = messagesEl.scrollHeight; }
      }else if(type === 'bot_stream_end'){
        streamMap.delete(data.msg_id);
      }else if(type === 'bot_stream_error'){
        const {content} = createMsgBubble({type:'bot', nick:data.nick||'成小理', text:data.text||'发生错误'});
        streamMap.delete(data.msg_id);
      }else{
        addMessage(data);
      }
    };
    ws.onclose = function(){ addMessage({type:'system', nick:'系统', text:'连接已关闭'}); };
    ws.onerror = function(){ addMessage({type:'system', nick:'系统', text:'连接出现错误'}); };
  }

  connect();

  function send(){
    const text = (msgInputEl.value||'').trim();
    if(!text) return;
    const payload = JSON.stringify({type:'chat', nick:NICK, text});
    ws && ws.readyState === WebSocket.OPEN ? ws.send(payload) : addMessage({type:'system', nick:'系统', text:'连接未就绪'});
    msgInputEl.value = '';
  }
  sendBtn.addEventListener('click', send);
  msgInputEl.addEventListener('keydown', (e)=>{
    if(e.key === 'Enter') { e.preventDefault(); send(); }
  });
})();