# 重置Session后测试
import importlib
import crawler
importlib.reload(crawler)

from crawler import crawl_baidu, BaiduCrawler

# 重置Session
BaiduCrawler._session = None

print("测试百度新闻搜索...")
results = crawl_baidu('西昌', count=5)
print(f"获取到 {len(results)} 条结果")

for i, r in enumerate(results):
    print(f"\n{i+1}. {r.get('title', '')[:40]}")
    print(f"   来源: {r.get('source', '')}")
