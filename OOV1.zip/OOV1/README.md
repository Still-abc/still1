# veichat

一个基于 Flask + WebSocket 的多人在线聊天应用。

## 功能特性

- **登录功能**: Instagram风格UI，支持昵称登录、服务器选择
- **多人群聊**: 实时消息推送，支持多人同时在线聊天
- **@功能**: 支持@成小理、@音乐、@电影、@天气、@新闻、@小视频（预留接口）
- **Emoji表情**: 丰富的Emoji表情选择器
- **历史记录**: 预留接口，功能建设中
- **响应式设计**: 自适应PC端和移动端

## 技术栈

- **后端**: Python 3 + Flask + Flask-Sock (WebSocket)
- **前端**: HTML5 + CSS3 + JavaScript + jQuery
- **通信**: WebSocket 实时通信

## 快速开始

### 1. 创建虚拟环境

```bash
cd e:\OOV1
python -m venv venv
```

### 2. 激活虚拟环境

Windows:
```bash
venv\Scripts\activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

### 4. 启动应用

```bash
python app.py
```

### 5. 访问应用

打开浏览器访问: http://localhost:5000

## 项目结构

```
OOV1/
├── app.py                 # Flask主应用
├── config.json            # 配置文件（服务器地址等）
├── requirements.txt       # Python依赖
├── README.md              # 项目说明
├── templates/             # HTML模板
│   ├── login.html         # 登录页面
│   └── chat.html          # 聊天室页面
└── static/                # 静态资源
    ├── css/
    │   ├── login.css      # 登录页样式
    │   └── chat.css       # 聊天室样式
    └── js/
        ├── jquery-3.7.1.min.js  # jQuery库
        ├── login.js       # 登录页脚本
        └── chat.js        # 聊天室脚本
```

## 配置说明

`config.json` 文件配置示例:

```json
{
    "servers": [
        {
            "name": "本地服务器",
            "url": "ws://localhost:5000/ws"
        }
    ],
    "app": {
        "name": "OO聊天室",
        "version": "1.0.0",
        "password": "123456"
    }
}
```

## 使用说明

1. **登录**: 输入昵称，密码为 `123456`，选择服务器后点击登录
2. **发送消息**: 在输入框输入内容，点击发送按钮或按回车键发送
3. **使用Emoji**: 点击😊按钮打开表情选择器
4. **@功能**: 点击@按钮选择功能，或直接输入@小理等
5. **退出**: 点击退出按钮返回登录页面

## 预留接口

以下功能已预留接口，后期可扩展实现:

- `@成小理` - AI助手
- `@音乐` - 音乐服务
- `@电影` - 电影推荐
- `@天气` - 天气查询
- `@新闻` - 新闻推送
- `@小视频` - 短视频
- 历史记录查看

## License

MIT License
