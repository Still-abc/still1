"""
数据抓取模块 - 百度搜索舆情数据采集
"""
import requests
from bs4 import BeautifulSoup
import re
import time
import random
from urllib.parse import quote, urljoin, urlparse


# 必应搜索Cookie（手动更新）
BING_COOKIE = '_EDGE_V=1; MUID=22D542A9FCCD6C07117457F1FD1F6D34; MUIDB=22D542A9FCCD6C07117457F1FD1F6D34; SRCHD=AF=NOFORM; SRCHUID=V=2&GUID=A4A40F36034B4135884467FE161BEE77&dmnchg=1; ANON=A=814D26D6F8E7CD8978760AF6FFFFFFFF; _TTSS_IN=hist=WyJ6aC1IYW5zIiwiZW4iLCJhdXRvLWRldGVjdCJd&isADRU=0; _TTSS_OUT=hist=WyJlbiIsInpoLUhhbnMiXQ==; _tarLang=default=zh-Hans; SRCHUSR=DOB=20241217&T=1743409416000&DS=1&POEX=W; MSPTC=k3UGycEamCKiHgi6y2LXM-kZyag9itVkLDZkD3m2d8E; _UR=QS=0&TQS=0&Pn=0; BFBUSR=BFBHP=0; MMCASM=ID=E1E300D18FFF464E98EE3353C00EE7C4; _uetvid=6baa801064a211f0b7482ddfc4c77a25; _clck=r5pqun%5E2%5Eg0h%5E0%5E1874; _EDGE_CD=m=ja-jp; MSCCSC=1; SNRHOP=I=&TS=; _U=1t6AtwHJDwLYakgwhh3bKAC6PKQ2wvtAouVkOBY2LbdHfjI_Kcg7xH1UyzpiKh7-0XAu15i5MhFBWAaC4m22jgtsLzJ0zIDfY1qkE4JOr7RGkMpL6aoghRiMb5WUqCJAS-wPeXvgni1CAoscNsFELgZF8qb_dN6AG7XkpDsgnxnYGOtoxBBeX1GA-WNkfoyuZ6QeQKZFC-ra9oHORdyDx5Q; _EDGE_S=SID=1EAC8BC4C0956A9413F69D7DC1476BE2&mkt=zh-CN; WLS=C=a7d8b64e5f8c00f4&N=ChengYi; USRLOC=HS=1&ELOC=LAT=28.82453155517578|LON=104.68185424804688|N=%E7%BF%A0%E5%B1%8F%E5%8C%BA%EF%BC%8C%E5%9B%9B%E5%B7%9D%E7%9C%81|ELT=2|&BLOCK=TS=251203145625&CLOC=LAT=28.820779000100355|LON=104.68104237166568|A=733.4464586120832|TS=251205005503|SRC=W&BID=MjUxMjA1MDg1NDU5X2E5NjZjZWUxNjBlYWNjYmU0MmQ3YzE3NjBhNmVmMDRhNzQ5NmE5ODM2Y2ZkYTc4ZjI1NzFhYjc2NzlmOGMzMTQ=; GC=UnE2QWh0th5y9_tHdyo-j1p3ARof1tGbNWgVrN5EzWltI8KrE0_uDcS1TLUv1M3hiQAGHoMsDWPUHJouuKr_gg; _Rwho=u=d&ts=2025-12-05; _SS=SID=1EAC8BC4C0956A9413F69D7DC1476BE2&PC=ASTS&R=839&RB=839&GB=0&RG=0&RP=839; _RwBf=mta=0&rc=839&rb=839&gb=2025w18_c&rg=0&pc=839&mtu=0&rbb=0.0&g=&cid=0&clo=0&v=4&l=2025-12-04T08:00:00.0000000Z&lft=0001-01-01T00:00:00.0000000&aof=0&ard=0001-01-01T00:00:00.0000000&rwdbt=-62135539200&rwflt=1743200982&rwaul2=0&o=0&p=MSAAUTOENROLL&c=MR000T&t=3291&s=2023-10-11T04:33:46.1192990+00:00&ts=2025-12-05T00:54:58.8014866+00:00&rwred=0&wls=0&wlb=0&wle=1&ccp=2&cpt=0&lka=0&lkt=0&aad=0&TH=&e=jGtuMRJP9s-xs3lyorhemIoqA9rd1TdMuSeiHLfgmuFWOz5Z-m-nyWWC2Cj10ECnrOclc2f1uY07muly3UIoMg&A=814D26D6F8E7CD8978760AF6FFFFFFFF&ispd=3; SRCHHPGUSR=SRCHLANG=zh-Hans&PV=19.0.0&BZA=0&DM=1&BRW=NOTP&BRH=M&CW=707&CH=742&SCW=692&SCH=742&DPR=1.3&UTC=480&EXLTT=31&HV=1764896097'




def clean_text(text):
    """
    清理文本中的脏数据
    
    Args:
        text: 原始文本
        
    Returns:
        str: 清理后的文本
    """
    if not text:
        return ''
    
    # 移除HTML标签残留
    text = re.sub(r'<[^>]+>', '', text)
    
    # 移除HTML实体
    text = re.sub(r'&[a-zA-Z]+;|&#\d+;', ' ', text)
    
    # 移除特殊Unicode字符（保留中文、英文、数字、常用标点）
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
    
    # 移除零宽字符
    text = re.sub(r'[\u200b-\u200f\u2028-\u202f\u205f-\u206f\ufeff]', '', text)
    
    # 规范化空白字符（多个空格/换行/制表符合并为单个空格）
    text = re.sub(r'[\s\t\n\r]+', ' ', text)
    
    # 移除首尾空白
    text = text.strip()
    
    # 移除重复标点
    text = re.sub(r'([。，！？、；：,.!?;:]){2,}', r'\1', text)
    
    # 移除百度搜索常见的干扰文本
    noise_patterns = [
        r'^百度快照$',
        r'^广告$',
        r'百度为您找到相关结果.*',
        r'\d+条相关',
        r'查看更多.*',
        r'展开全部',
        r'^\d+年\d+月\d+日\s*[-—]?\s*',  # 移除开头的日期
    ]
    for pattern in noise_patterns:
        text = re.sub(pattern, '', text)
    
    return text.strip()


def clean_url(url):
    """
    清理URL
    
    Args:
        url: 原始URL
        
    Returns:
        str: 清理后的URL
    """
    if not url:
        return ''
    
    url = url.strip()
    
    # 移除URL中的空白字符
    url = re.sub(r'\s+', '', url)
    
    # 确保URL格式正确
    if url and not url.startswith(('http://', 'https://')):
        if url.startswith('//'):
            url = 'https:' + url
    
    return url


def clean_source(source):
    """
    清理来源信息
    
    Args:
        source: 原始来源
        
    Returns:
        str: 清理后的来源
    """
    if not source:
        return ''
    
    source = clean_text(source)
    
    # 移除来源中常见的干扰内容
    source = re.sub(r'https?://[^\s]*', '', source)  # 移除URL
    source = re.sub(r'www\.[^\s]*', '', source)  # 移除www开头的域名
    source = re.sub(r'\d{4}[-/]\d{1,2}[-/]\d{1,2}', '', source)  # 移除日期
    source = re.sub(r'\d+小时前|\d+分钟前|\d+天前|昨天|前天', '', source)  # 移除相对时间
    
    # 只保留来源名称（通常在最前面）
    source = source.split('-')[0].split('_')[0].split('|')[0]
    
    return source.strip()


def clean_result_item(item):
    """
    清理单个搜索结果项的所有字段
    
    Args:
        item: 原始结果项字典
        
    Returns:
        dict: 清理后的结果项
    """
    if not item:
        return None
    
    cleaned = {
        'title': clean_text(item.get('title', '')),
        'summary': clean_text(item.get('summary', '')),
        'cover': clean_url(item.get('cover', '')),
        'cover_fallback': clean_url(item.get('cover_fallback', '')),
        'url': clean_url(item.get('url', '')),
        'source': clean_source(item.get('source', ''))
    }
    
    # 如果标题和摘要相同，清空摘要避免重复
    if cleaned['title'] and cleaned['summary'] == cleaned['title']:
        cleaned['summary'] = ''
    
    # 截断过长的摘要
    if len(cleaned['summary']) > 500:
        cleaned['summary'] = cleaned['summary'][:500] + '...'
    
    return cleaned


def resolve_redirect_url(url):
    """
    解析跳转链接获取真实URL
    支持搜狗、360等搜索引擎的跳转链接
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        }
        
        # 搜狗跳转链接处理
        if 'sogou.com/link' in url or 'sogou.com/web' in url:
            response = requests.head(url, headers=headers, timeout=10, allow_redirects=True)
            if response.url and 'sogou.com' not in response.url:
                return response.url
            # 如果HEAD请求没有跳转，尝试GET请求
            response = requests.get(url, headers=headers, timeout=10, allow_redirects=True)
            return response.url
        
        # 360跳转链接处理
        if 'so.com/link' in url:
            response = requests.head(url, headers=headers, timeout=10, allow_redirects=True)
            return response.url
        
        # 百度跳转链接处理
        if 'baidu.com/link' in url:
            response = requests.head(url, headers=headers, timeout=10, allow_redirects=True)
            return response.url
        
        return url
    except Exception as e:
        print(f"解析跳转URL失败: {e}")
        return url


class BaiduCrawler:
    """搜索数据抓取器"""
    
    # 百度新闻搜索接口
    BAIDU_NEWS_URL = "https://www.baidu.com/s"
    
    # 全局Session
    _session = None
    
    def __init__(self):
        """初始化爬虫"""
        if BaiduCrawler._session is None:
            BaiduCrawler._session = requests.Session()
        self.session = BaiduCrawler._session
    
    def _get_headers(self):
        """获取百度新闻搜索请求头"""
        return {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Sec-Ch-Ua': '"Chromium";v="142", "Microsoft Edge";v="142", "Not_A Brand";v="99"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
        }
    
    def search(self, keyword, page=1, page_size=10, engine='auto'):
        """
        搜索关键字并返回新闻结果
        
        Args:
            keyword: 搜索关键字
            page: 页码，从1开始
            page_size: 每页结果数量
            engine: 搜索引擎 (auto/baidu/bing/sogou/360)
            
        Returns:
            list: 搜索结果列表，每项包含：
                - title: 标题
                - summary: 概要
                - cover: 封面图片URL
                - url: 原始URL
                - source: 来源
        """
        # 自动模式：优先尝试必应，失败则尝试百度
        if engine == 'auto':
            # 先尝试必应
            results = self._search_bing(keyword, page)
            if results:
                return results
            # 必应失败则尝试百度
            results = self._search_baidu_news(keyword, page)
            if results:
                return results
            # 都失败则尝试搜狗
            return self._search_sogou(keyword, page)
        elif engine == 'baidu':
            return self._search_baidu_news(keyword, page)
        elif engine == 'bing':
            return self._search_bing(keyword, page)
        elif engine == 'sogou':
            return self._search_sogou(keyword, page)
        elif engine == '360':
            return self._search_360(keyword, page)
        else:
            return self._search_bing(keyword, page)
    
    def _search_baidu_news(self, keyword, page=1):
        """百度新闻搜索"""
        results = []
        
        try:
            # 百度新闻搜索参数
            # rtt=1&bsst=1&cl=2&tn=news&rsv_dl=ns_pc&word=关键字
            params = {
                'rtt': '1',
                'bsst': '1', 
                'cl': '2',
                'tn': 'news',
                'rsv_dl': 'ns_pc',
                'word': keyword,
                'pn': (page - 1) * 10,  # 分页参数
            }
            
            time.sleep(random.uniform(0.3, 0.8))
            
            response = self.session.get(
                self.BAIDU_NEWS_URL,
                params=params,
                headers=self._get_headers(),
                timeout=15
            )
            response.raise_for_status()
            response.encoding = response.apparent_encoding or 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 解析百度新闻搜索结果
            seen_urls = set()
            
            # 百度新闻结果容器选择器 - 使用div.c-container
            news_items = soup.select('div.c-container')
            
            for item_div in news_items:
                try:
                    item = self._parse_baidu_news_item(item_div)
                    if item and item['url'] and item['url'] not in seen_urls:
                        seen_urls.add(item['url'])
                        item = clean_result_item(item)
                        if item and item['title']:
                            results.append(item)
                except Exception as e:
                    continue
            
            print(f"百度新闻搜索 '{keyword}' 获取到 {len(results)} 条结果")
                        
        except Exception as e:
            print(f"百度新闻搜索异常: {e}")
            import traceback
            traceback.print_exc()
        
        return results
    
    def _parse_baidu_news_item(self, item_div):
        """解析百度新闻搜索结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        # 标题和链接 - 使用h3 a选择器
        title_elem = item_div.select_one('h3 a')
        if not title_elem:
            title_elem = item_div.select_one('a[href*="baidu.com"]')
        
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            item['url'] = title_elem.get('href', '')
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        # 过滤广告和无效链接
        if not item['url'] or 'javascript:' in item['url']:
            return None
        
        # 摘要/概要 - 按优先级尝试多个选择器
        summary_selectors = [
            'span.content-right_8Zs40',
            'span.c-color-text', 
            '.c-summary',
            '.c-abstract',
        ]
        for sel in summary_selectors:
            summary_elem = item_div.select_one(sel)
            if summary_elem:
                item['summary'] = summary_elem.get_text(strip=True)
                break
        
        # 封面图片
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            # 使用百度默认图标
            item['cover'] = 'https://www.baidu.com/favicon.ico'
        
        # 来源信息
        source_elem = item_div.select_one('span.c-color-gray')
        if not source_elem:
            source_elem = item_div.select_one('span.news-source_2LRzg, .c-source')
        if source_elem:
            source_text = source_elem.get_text(strip=True)
            # 提取来源名称（通常格式为"来源名 时间"）
            item['source'] = source_text.split()[0] if source_text else ''
        
        if not item['source']:
            item['source'] = '百度新闻'
        
        return item
    
    def _search_sogou(self, keyword, page=1):
        """搜狗新闻搜索"""
        results = []
        
        try:
            params = {'query': keyword, 'mode': '1', 'page': page}
            time.sleep(random.uniform(0.5, 1.0))
            
            response = self.session.get(
                "https://news.sogou.com/news",
                params=params,
                headers=self._get_headers(referer='https://news.sogou.com/'),
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            news_items = soup.select('div.vrwrap, div.news-item, div.rb')
            
            seen_titles = set()
            for item_div in news_items:
                try:
                    item = self._parse_sogou_item(item_div)
                    if item and item['title'] not in seen_titles:
                        seen_titles.add(item['title'])
                        item = clean_result_item(item)
                        if item:
                            results.append(item)
                except:
                    continue
        except Exception as e:
            print(f"搜狗搜索异常: {e}")
        
        return results
    
    def _search_360(self, keyword, page=1):
        """360搜索"""
        results = []
        
        try:
            params = {'q': keyword, 'pn': page, 'ie': 'utf-8'}
            time.sleep(random.uniform(0.5, 1.0))
            
            response = self.session.get(
                "https://www.so.com/s",
                params=params,
                headers=self._get_headers(referer='https://www.so.com/'),
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            result_items = soup.select('li.res-list, div.result')
            
            seen_titles = set()
            for item_div in result_items:
                try:
                    item = self._parse_360_item(item_div)
                    if item and item['title'] not in seen_titles:
                        seen_titles.add(item['title'])
                        item = clean_result_item(item)
                        if item:
                            results.append(item)
                except:
                    continue
        except Exception as e:
            print(f"360搜索异常: {e}")
        
        return results
    
    def _parse_sogou_item(self, item_div):
        """解析搜狗新闻结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        title_elem = item_div.select_one('h3 a, a.news-title')
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            href = title_elem.get('href', '')
            item['url'] = 'https://news.sogou.com' + href if href.startswith('/link') else href
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        summary_elem = item_div.select_one('.ft, .news-txt, p.txt-info')
        if summary_elem:
            item['summary'] = summary_elem.get_text(strip=True)
        
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            item['cover'] = 'https://www.sogou.com/favicon.ico'
        
        source_elem = item_div.select_one('.news-from, cite, span.citeurl')
        if source_elem:
            item['source'] = source_elem.get_text(strip=True).split(' ')[0].split('\xa0')[0]
        if not item['source']:
            item['source'] = '网络新闻'
        
        return item
    
    def _parse_360_item(self, item_div):
        """解析360搜索结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        title_elem = item_div.select_one('h3 a, a[href]')
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            href = title_elem.get('href', '') or title_elem.get('data-url', '')
            item['url'] = href if href.startswith('http') else 'https://www.so.com' + href
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        summary_elem = item_div.select_one('.res-desc, .res-rich, p')
        if summary_elem:
            item['summary'] = summary_elem.get_text(strip=True)
        
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            item['cover'] = 'https://www.so.com/favicon.ico'
        
        # 从URL提取来源
        if item['url']:
            try:
                parsed = urlparse(item['url'])
                if parsed.netloc and 'so.com' not in parsed.netloc:
                    item['source'] = parsed.netloc.replace('www.', '')
            except:
                pass
        if not item['source']:
            item['source'] = '网络来源'
        
        return item
    
    def _search_bing(self, keyword, page=1):
        """必应搜索"""
        results = []
        
        try:
            # 直接使用必应网页搜索
            params = {
                'q': keyword,
                'first': (page - 1) * 10 + 1,
            }
            time.sleep(random.uniform(0.3, 0.8))
            
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
                'Cache-Control': 'max-age=0',
                'Cookie': BING_COOKIE,
                'Sec-Ch-Ua': '"Chromium";v="142", "Microsoft Edge";v="142", "Not_A Brand";v="99"',
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Windows"',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36 Edg/142.0.0.0',
            }
            
            # 使用新的requests直接请求，不用session
            response = requests.get(
                "https://www.bing.com/search",
                params=params,
                headers=headers,
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 必应搜索结果选择器
            seen_urls = set()
            
            # 主要结果
            for item_div in soup.select('li.b_algo'):
                try:
                    item = self._parse_bing_web_item(item_div)
                    if item and item['url'] not in seen_urls:
                        seen_urls.add(item['url'])
                        item = clean_result_item(item)
                        if item:
                            results.append(item)
                except Exception as e:
                    print(f"解析必应结果项失败: {e}")
                    continue
            
            print(f"必应搜索 '{keyword}' 获取到 {len(results)} 条结果")
                        
        except Exception as e:
            print(f"必应搜索异常: {e}")
            import traceback
            traceback.print_exc()
        
        return results
    
    def _parse_bing_item(self, item_div):
        """解析必应新闻结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        title_elem = item_div.select_one('a.title, a[href]')
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            item['url'] = title_elem.get('href', '')
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        summary_elem = item_div.select_one('.snippet, .caption')
        if summary_elem:
            item['summary'] = summary_elem.get_text(strip=True)
        
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            item['cover'] = 'https://cn.bing.com/favicon.ico'
        
        source_elem = item_div.select_one('.source, cite')
        if source_elem:
            item['source'] = source_elem.get_text(strip=True).split(' ')[0]
        if not item['source']:
            item['source'] = '必应新闻'
        
        return item
    
    def _parse_bing_web_item(self, item_div):
        """解析必应网页搜索结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        # 标题和链接 - 尝试多种选择器
        title_elem = item_div.select_one('h2 a')
        if not title_elem:
            title_elem = item_div.select_one('a[href^="http"]')
        
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            item['url'] = title_elem.get('href', '')
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        # 过滤必应内部链接
        if item['url'] and 'bing.com' in item['url']:
            return None
        
        # 过滤知乎
        if item['url'] and 'zhihu.com' in item['url']:
            return None
        
        # 摘要 - 尝试多种选择器
        for sel in ['.b_caption p', 'p.b_lineclamp2', 'p.b_lineclamp3', 'p.b_lineclamp4', '.b_caption', 'p']:
            summary_elem = item_div.select_one(sel)
            if summary_elem:
                text = summary_elem.get_text(strip=True)
                if len(text) > 20:
                    item['summary'] = text
                    break
        
        # 封面图片
        img_elem = item_div.select_one('img[src^="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '')
        if not item['cover']:
            item['cover'] = 'https://cn.bing.com/favicon.ico'
        
        # 从URL提取来源
        if item['url']:
            try:
                parsed = urlparse(item['url'])
                if parsed.netloc:
                    item['source'] = parsed.netloc.replace('www.', '')
            except:
                pass
        if not item['source']:
            item['source'] = '网络来源'
        
        return item
    
    def _search_baidu(self, keyword, page=1):
        """百度搜索"""
        results = []
        
        try:
            # 百度新闻搜索
            params = {
                'word': keyword,
                'pn': (page - 1) * 10,
                'tn': 'news',
                'ie': 'utf-8'
            }
            time.sleep(random.uniform(0.5, 1.0))
            
            response = self.session.get(
                "https://www.baidu.com/s",
                params=params,
                headers=self._get_headers(referer='https://www.baidu.com/'),
                timeout=15
            )
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 百度搜索结果选择器
            result_items = soup.select('div.result, div.c-container, div.result-op')
            
            seen_titles = set()
            for item_div in result_items:
                try:
                    item = self._parse_baidu_item(item_div)
                    if item and item['title'] not in seen_titles:
                        seen_titles.add(item['title'])
                        item = clean_result_item(item)
                        if item:
                            results.append(item)
                except:
                    continue
                    
        except Exception as e:
            print(f"百度搜索异常: {e}")
        
        return results
    
    def _parse_baidu_item(self, item_div):
        """解析百度搜索结果项"""
        item = {'title': '', 'url': '', 'summary': '', 'cover': '', 'cover_fallback': '', 'source': ''}
        
        # 标题和链接
        title_elem = item_div.select_one('h3 a, a.c-title')
        if title_elem:
            item['title'] = title_elem.get_text(strip=True)
            item['url'] = title_elem.get('href', '')
        
        if not item['title'] or len(item['title']) < 3:
            return None
        
        # 摘要
        summary_elem = item_div.select_one('.c-abstract, .content-right_8Zs40, span.content-right_8Zs40')
        if summary_elem:
            item['summary'] = summary_elem.get_text(strip=True)
        if not item['summary']:
            # 尝试其他摘要选择器
            for sel in ['.c-span-last', '.c-row', 'p']:
                elem = item_div.select_one(sel)
                if elem:
                    text = elem.get_text(strip=True)
                    if len(text) > 20:
                        item['summary'] = text
                        break
        
        # 封面图片
        img_elem = item_div.select_one('img[src*="http"]')
        if img_elem:
            item['cover'] = img_elem.get('src', '') or img_elem.get('data-src', '')
        if not item['cover']:
            item['cover'] = 'https://www.baidu.com/favicon.ico'
        
        # 来源
        source_elem = item_div.select_one('.c-color-gray, .source_1Vdff, span.c-color-gray2')
        if source_elem:
            item['source'] = source_elem.get_text(strip=True).split(' ')[0].split('-')[0]
        if not item['source']:
            # 从URL提取来源
            if item['url'] and not item['url'].startswith('https://www.baidu.com'):
                try:
                    parsed = urlparse(item['url'])
                    if parsed.netloc:
                        item['source'] = parsed.netloc.replace('www.', '')
                except:
                    pass
        if not item['source']:
            item['source'] = '百度搜索'
        
        return item

# 来源类型匹配规则
SOURCE_TYPE_PATTERNS = {
    'baike': ['baike.baidu.com', 'baike.so.com', 'baike.sogou.com', 'wiki', '百科'],
    'news': ['news', 'sina.com', 'sohu.com', 'qq.com', '163.com', 'ifeng.com', 'people.com', 
             'xinhua', 'cctv', 'chinanews', '新闻', '资讯', '报'],
    'gov': ['.gov.cn', '.gov.com', '政府', '政务', '人民政府'],
    'zhihu': ['zhihu.com', '知乎'],
    'weibo': ['weibo.com', 'weibo.cn', '微博'],
    'video': ['bilibili', 'youku', 'iqiyi', 'v.qq.com', 'douyin', 'kuaishou', 
              'video', '视频', 'tv.'],
    'map': ['map.', 'ditu.', 'amap.com', 'map.qq.com', 'map.baidu.com', '地图'],
}


def match_source_type(source, url, source_type):
    """
    检查来源是否匹配指定类型
    
    Args:
        source: 来源字符串
        url: URL字符串
        source_type: 来源类型
        
    Returns:
        bool: 是否匹配
    """
    if not source_type:
        return True  # 不筛选
    
    if source_type == 'other':
        # 其他来源：不匹配任何已知类型
        for patterns in SOURCE_TYPE_PATTERNS.values():
            for pattern in patterns:
                if pattern.lower() in source.lower() or pattern.lower() in url.lower():
                    return False
        return True
    
    patterns = SOURCE_TYPE_PATTERNS.get(source_type, [])
    for pattern in patterns:
        if pattern.lower() in source.lower() or pattern.lower() in url.lower():
            return True
    return False


def crawl_baidu(keyword, count=10, source_type=''):
    """
    爬取搜索结果的便捷函数
    
    Args:
        keyword: 搜索关键字
        count: 需要采集的条数
        source_type: 来源类型筛选（baike/news/gov/zhihu/weibo/video/map/other）
        
    Returns:
        list: 搜索结果列表，每项包含：
            - title: 标题
            - summary: 概要
            - cover: 封面图片URL
            - url: 原始URL
            - source: 来源
    """
    crawler = BaiduCrawler()
    all_results = []
    seen_urls = set()  # 用于去重
    page = 1
    max_pages = 10  # 限制最大页数
    empty_page_count = 0  # 连续空页计数
    max_empty_pages = 2  # 连续空页阈值
    
    while len(all_results) < count and page <= max_pages:
        results = crawler.search(keyword, page=page)
        
        if not results:
            print(f"第{page}页无结果，停止采集")
            break  # 没有更多结果了
        
        # 检查是否有新结果（去重）
        new_results_count = 0
        matched_count = 0
        
        # 根据来源类型筛选
        for item in results:
            url = item.get('url', '')
            if url in seen_urls:
                continue  # 跳过重复结果
            seen_urls.add(url)
            new_results_count += 1
            
            if match_source_type(item.get('source', ''), url, source_type):
                all_results.append(item)
                matched_count += 1
                if len(all_results) >= count:
                    break
        
        print(f"第{page}页: 获取{len(results)}条, 新增{new_results_count}条, 匹配{matched_count}条, 累计{len(all_results)}条")
        
        # 如果本页没有新结果或没有匹配结果，增加空页计数
        if new_results_count == 0 or (source_type and matched_count == 0):
            empty_page_count += 1
            if empty_page_count >= max_empty_pages:
                print(f"连续{empty_page_count}页无有效结果，停止采集")
                break
        else:
            empty_page_count = 0  # 重置空页计数
        
        page += 1
        
        if len(all_results) < count and page <= max_pages:
            time.sleep(random.uniform(0.3, 0.6))  # 页面间延迟
    
    # 返回指定数量的结果
    return all_results[:count]


def match_url_pattern(url, pattern):
    """
    检查URL是否匹配规则模式
    
    Args:
        url: 要检查的URL
        pattern: 匹配模式（支持通配符*或正则表达式）
        
    Returns:
        bool: 是否匹配
    """
    import fnmatch
    
    # 先尝试通配符匹配
    if '*' in pattern:
        return fnmatch.fnmatch(url, pattern)
    
    # 尝试正则表达式匹配
    try:
        return bool(re.search(pattern, url))
    except:
        # 如果正则无效，尝试简单包含匹配
        return pattern.lower() in url.lower()


def deep_crawl(url, rule=None):
    """
    深度采集单个URL的内容
    
    Args:
        url: 要采集的URL
        rule: 采集规则字典，包含title_xpath, content_xpath, request_headers等
        
    Returns:
        dict: 包含content(正文)、summary(摘要)、real_url(真实URL)的字典
    """
    from lxml import etree
    
    result = {
        'content': '',
        'summary': '',
        'real_url': url
    }
    
    try:
        # 先解析跳转链接获取真实URL
        real_url = resolve_redirect_url(url)
        if real_url != url:
            print(f"跳转URL解析: {url} -> {real_url}")
            url = real_url
        
        # 默认请求头 - 模拟真实浏览器
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0',
        }
        
        # 如果有自定义headers，合并
        if rule and rule.get('request_headers'):
            try:
                custom_headers = json.loads(rule['request_headers'])
                headers.update(custom_headers)
            except:
                pass
        
        # 发送请求，允许重定向以获取真实URL
        response = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        result['real_url'] = response.url  # 获取重定向后的真实URL
        response.encoding = response.apparent_encoding or 'utf-8'
        
        html_text = response.text
        
        # 检测是否是搜索引擎的错误页面
        error_indicators = [
            '页面暂时打不开', '孩子迷路啦', '页面不存在', '404',
            '访问出错', '无法访问', '页面已删除'
        ]
        for indicator in error_indicators:
            if indicator in html_text[:2000]:
                print(f"检测到错误页面: {indicator}")
                result['content'] = ''
                return result
        
        content = ''
        
        # 如果有自定义XPath规则，优先使用
        if rule and rule.get('content_xpath'):
            try:
                tree = etree.HTML(html_text)
                content_elements = tree.xpath(rule['content_xpath'])
                if content_elements:
                    # 提取文本内容
                    texts = []
                    for elem in content_elements:
                        if isinstance(elem, str):
                            texts.append(elem)
                        else:
                            texts.append(etree.tostring(elem, encoding='unicode', method='text'))
                    content = '\n'.join(texts)
                    print(f"使用自定义XPath规则采集成功: {rule.get('name', 'unknown')}")
            except Exception as e:
                print(f"XPath解析失败: {e}")
        
        # 如果XPath没有获取到内容，使用默认方式
        if not content or len(content) < 50:
            soup = BeautifulSoup(html_text, 'html.parser')
            
            # 移除脚本和样式
            for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'iframe', 'noscript', 'form', 'button']):
                tag.decompose()
            
            # 更全面的正文容器选择器
            content_selectors = [
                'article',
                '.article-content',
                '.article_content',
                '.articleContent',
                '.post-content',
                '.post_content',
                '.postContent',
                '.entry-content',
                '.entry_content',
                '.content',
                '.main-content',
                '.main_content',
                '#content',
                '#article',
                '#main',
                '.article',
                '.post',
                '.news-content',
                '.news_content',
                '.newsContent',
                '.detail-content',
                '.detail_content',
                '.detailContent',
                '.txt',
                '.text',
                '.body',
                'main',
                '[class*="article"]',
                '[class*="content"]',
                '[class*="detail"]',
                '[class*="news"]',
                '[id*="article"]',
                '[id*="content"]',
            ]
            
            for selector in content_selectors:
                try:
                    elem = soup.select_one(selector)
                    if elem:
                        content = elem.get_text(separator='\n', strip=True)
                        if len(content) > 100:
                            print(f"使用选择器 {selector} 获取到内容，长度: {len(content)}")
                            break
                except:
                    continue
            
            # 如果没找到，尝试获取body中最大的文本块
            if not content or len(content) < 100:
                body = soup.find('body')
                if body:
                    # 获取所有段落
                    paragraphs = body.find_all(['p', 'div', 'section'])
                    texts = []
                    for p in paragraphs:
                        text = p.get_text(strip=True)
                        if len(text) > 30:  # 降低阈值
                            texts.append(text)
                    content = '\n'.join(texts)
                    if content:
                        print(f"使用段落提取获取到内容，长度: {len(content)}")
            
            # 最后尝试：直接获取body文本
            if not content or len(content) < 50:
                body = soup.find('body')
                if body:
                    content = body.get_text(separator='\n', strip=True)
                    print(f"使用body全文提取，长度: {len(content)}")
            
            # 强制采集：如果还是没内容，获取整个HTML的文本
            if not content:
                content = soup.get_text(separator='\n', strip=True)
                print(f"强制采集整页文本，长度: {len(content)}")
        
        # 清理内容
        content = clean_text(content)
        
        # 如果内容仍然为空，尝试从原始HTML提取
        if not content or len(content) < 20:
            # 使用正则直接提取中文内容
            import re
            chinese_text = re.findall(r'[\u4e00-\u9fa5，。！？、；：""''（）【】]+', html_text)
            if chinese_text:
                content = ''.join(chinese_text)
                print(f"正则提取中文内容，长度: {len(content)}")
        
        # 截断过长内容
        if len(content) > 5000:
            content = content[:5000] + '...'
        
        result['content'] = content
        
        # 生成摘要（取前300字）
        if content:
            summary = content[:300]
            if len(content) > 300:
                summary += '...'
            result['summary'] = summary
            
    except Exception as e:
        print(f"深度采集失败 {url}: {e}")
    
    return result


def deep_crawl_batch(urls, rules=None):
    """
    批量深度采集多个URL
    
    Args:
        urls: URL列表
        rules: 采集规则列表，每个规则包含url_pattern, title_xpath, content_xpath, request_headers
        
    Returns:
        list: 采集结果列表
    """
    results = []
    rules = rules or []
    
    for url in urls:
        # 查找匹配的规则
        matched_rule = None
        for rule in rules:
            if match_url_pattern(url, rule.get('url_pattern', '')):
                matched_rule = rule
                print(f"URL匹配规则: {rule.get('name', 'unknown')} -> {url}")
                break
        
        result = deep_crawl(url, rule=matched_rule)
        result['url'] = url  # 保留原始URL用于匹配
        results.append(result)
        time.sleep(random.uniform(0.5, 1))  # 请求间延迟
    return results


# 测试代码
if __name__ == '__main__':
    keyword = "西昌"
    print(f"正在搜索关键字: {keyword}")
    print("-" * 50)
    
    results = crawl_baidu(keyword, pages=1)
    
    for i, item in enumerate(results, 1):
        print(f"\n【结果 {i}】")
        print(f"标题: {item['title']}")
        print(f"概要: {item['summary'][:100]}..." if len(item['summary']) > 100 else f"概要: {item['summary']}")
        print(f"封面: {item['cover']}")
        print(f"原始URL: {item['url']}")
        print(f"来源: {item['source']}")
    
    print(f"\n共获取 {len(results)} 条结果")
